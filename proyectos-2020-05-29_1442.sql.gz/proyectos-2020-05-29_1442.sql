-- MySQL dump 10.13  Distrib 5.7.30, for Linux (x86_64)
--
-- Host: localhost    Database: proyectos
-- ------------------------------------------------------
-- Server version	5.7.30-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group__permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_group__permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permission_group_id_689710a9a73b7457_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  CONSTRAINT `auth__content_type_id_508cf46651277a81_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can add permission',2,'add_permission'),(5,'Can change permission',2,'change_permission'),(6,'Can delete permission',2,'delete_permission'),(7,'Can add group',3,'add_group'),(8,'Can change group',3,'change_group'),(9,'Can delete group',3,'delete_group'),(10,'Can add user',4,'add_user'),(11,'Can change user',4,'change_user'),(12,'Can delete user',4,'delete_user'),(13,'Can add content type',5,'add_contenttype'),(14,'Can change content type',5,'change_contenttype'),(15,'Can delete content type',5,'delete_contenttype'),(16,'Can add session',6,'add_session'),(17,'Can change session',6,'change_session'),(18,'Can delete session',6,'delete_session'),(19,'Can add orientacion',7,'add_orientacion'),(20,'Can change orientacion',7,'change_orientacion'),(21,'Can delete orientacion',7,'delete_orientacion'),(22,'Can add alumno',8,'add_alumno'),(23,'Can change alumno',8,'change_alumno'),(24,'Can delete alumno',8,'delete_alumno'),(25,'Can add director',9,'add_director'),(26,'Can change director',9,'change_director'),(27,'Can delete director',9,'delete_director'),(28,'Can add proyecto',10,'add_proyecto'),(29,'Can change proyecto',10,'change_proyecto'),(30,'Can delete proyecto',10,'delete_proyecto'),(31,'Can add plan',11,'add_plan'),(32,'Can change plan',11,'change_plan'),(33,'Can delete plan',11,'delete_plan');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$36000$APEiDKU9MBuk$M1SAz+v1vijnRBvrIWcsJ7/4L44f4BGXyL+Y9p93tyU=','2019-06-17 16:31:19',1,'cgallo','Cristián','Gallo','mail@cristiangallo.com.ar',1,1,'2018-03-24 22:39:59'),(2,'pbkdf2_sha256$36000$zRXT2Su0RMce$EU+Hgx4b1MFddKckNikqZSNh6xSLyciG2+FL1Nu1RpQ=','2020-05-14 13:11:02',1,'agentile','Aldo','Gentile','aldogentile.proyectoeie@gmail.com',1,1,'2018-03-24 23:59:46'),(3,'pbkdf2_sha256$20000$9SmzD5vduAX1$tFjhZgdkqHaz6LXKPycr7IlgwEncYfDkFJkviynd2xg=','2018-05-16 00:24:42',1,'anovello','','','',1,1,'2018-03-27 23:34:51');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_u_permission_id_384b62483d7071f0_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_user_u_permission_id_384b62483d7071f0_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissi_user_id_7f0938558328534a_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
INSERT INTO `auth_user_user_permissions` VALUES (3,3,1);
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `djang_content_type_id_697914295151027a_fk_django_content_type_id` (`content_type_id`),
  KEY `django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id` (`user_id`),
  CONSTRAINT `djang_content_type_id_697914295151027a_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=418 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2018-03-24 22:41:38','1','Plan 99',1,'',7,1),(2,'2018-03-24 22:41:56','2','Comunicaciones',1,'',7,1),(3,'2018-03-24 22:42:05','3','Control',1,'',7,1),(4,'2018-03-24 22:42:11','4','Digital',1,'',7,1),(5,'2018-03-24 22:42:58','6','Diseño electrónico',1,'',7,1),(6,'2018-03-24 22:43:28','1','Gentile Aldo',1,'',9,1),(7,'2018-03-24 22:44:08','1','Almiron Nehuen',1,'',8,1),(8,'2018-03-24 22:49:15','1','Prueba - Gentile Aldo',1,'',10,1),(9,'2018-03-24 23:08:56','2','Falco Eduardo',1,'',9,1),(10,'2018-03-24 23:14:42','7','Plan 96',1,'',7,1),(11,'2018-03-24 23:59:46','2','agentile',1,'',4,1),(12,'2018-03-25 00:00:04','2','agentile',2,'Modifica first_name, last_name, email, is_staff y is_superuser.',4,1),(13,'2018-03-25 00:00:58','2','Falco Eduardo',3,'',9,1),(14,'2018-03-25 00:02:12','4','Barria Cardenas Alex',2,'Modifica orientacion.',8,1),(15,'2018-03-25 00:02:22','5','Bureu Clara',2,'Modifica orientacion.',8,1),(16,'2018-03-25 00:02:33','6','Carnevale Ignacio',2,'Modifica orientacion.',8,1),(17,'2018-03-25 00:02:43','7','Casá José',2,'Modifica orientacion.',8,1),(18,'2018-03-25 00:03:21','8','Cavalieri Jun Ignacio',2,'Modifica orientacion.',8,1),(19,'2018-03-25 00:03:31','9','Chavarini Augusto',2,'Modifica orientacion.',8,1),(20,'2018-03-25 00:03:41','10','Chaya Ian',2,'Modifica orientacion.',8,1),(21,'2018-03-25 00:03:53','11','Depetris Augusto',2,'Modifica orientacion.',8,1),(22,'2018-03-25 00:04:05','12','Díaz Paula',2,'Modifica orientacion.',8,1),(23,'2018-03-25 00:04:17','13','Dominguez Mauro',2,'Modifica orientacion.',8,1),(24,'2018-03-25 00:04:33','15','Entesano Francisco',2,'Modifica orientacion.',8,1),(25,'2018-03-27 23:34:51','3','anovello',1,'',4,2),(26,'2018-03-27 23:35:32','3','Novello Armando',1,'',9,2),(27,'2018-03-27 23:35:53','4','Geninatti Sergio',1,'',9,2),(28,'2018-03-27 23:36:39','6','Romero Monica',1,'',9,2),(29,'2018-03-27 23:36:55','6','Romero Monica',2,'No ha modificado ningún campo.',9,2),(30,'2018-03-27 23:37:12','7','Vazquez Andres',1,'',9,2),(31,'2018-03-27 23:37:29','8','Gomez Juan Carlos',1,'',9,2),(32,'2018-03-27 23:37:46','9','Miyara Federico',1,'',9,2),(33,'2018-03-27 23:38:05','10','Mare Renzo',1,'',9,2),(34,'2018-03-27 23:38:19','11','Iglesias Natalia',1,'',9,2),(35,'2018-03-27 23:38:34','12','Arraigada Fernando',1,'',9,2),(36,'2018-03-27 23:38:50','13','Simon Jose Luis',1,'',9,2),(37,'2018-03-27 23:41:37','14','Pastelleto Sergio',1,'',9,2),(38,'2018-03-27 23:41:48','15','Molina Hector',1,'',9,2),(39,'2018-03-27 23:42:01','16','Miro Veronica',1,'',9,2),(40,'2018-03-27 23:42:22','17','Rubio Scola Eduardo',1,'',9,2),(41,'2018-03-27 23:44:41','18','Alba Daniel',1,'',9,2),(42,'2018-03-27 23:44:54','19','Cavello Javier',1,'',9,2),(43,'2018-03-27 23:45:40','20','Corti Rosa',1,'',9,2),(44,'2018-03-27 23:45:51','21','Junco Sergio',1,'',9,2),(45,'2018-03-29 18:10:24','16','Miro Verónica',2,'Modifica nombre.',9,1),(46,'2018-03-29 18:10:37','6','Romero Mónica',2,'Modifica nombre.',9,1),(47,'2018-04-03 23:57:14','2','Comunicación VX2: estudio e implementación del protocolo IEEE802.11p utilizando tecnologia de Radio Definida por Software  (SDR) - Iglesias Natalia',1,'',10,2),(48,'2018-04-03 23:59:39','3','Desarrollo de Instrumentos Digitalesde posición aeronáutica - Gentile Aldo',1,'',10,2),(49,'2018-04-04 00:01:45','40','Racca Ignacio',1,'',8,2),(50,'2018-04-04 00:02:12','3','Desarrollo de Instrumentos Digitalesde posición aeronáutica - Gentile Aldo',2,'Modifica alumnos.',10,2),(51,'2018-05-12 18:09:41','41','Manavella Matías Nicolas',1,'',8,2),(52,'2018-05-12 18:09:51','41','Manavella Matías Nicolas',2,'No ha modificado ningún campo.',8,2),(53,'2018-05-12 18:10:50','42','Acerbo Agustín',1,'',8,2),(54,'2018-05-12 18:12:13','43','Rozas Martín ',1,'',8,2),(55,'2018-05-12 18:14:09','4','Sistema electrónico de control de procesos - Pastelleto Sergio',1,'',10,2),(56,'2018-05-12 18:15:16','44','Soria Leandro',1,'',8,2),(57,'2018-05-12 18:16:53','22','Pizzi Analia',1,'',9,2),(58,'2018-05-12 18:17:20','5','Sistema de enlace inlámbrio de bajo consumo - Molina Hector',1,'',10,2),(59,'2018-05-13 16:52:30','3','anovello',2,'Modifica user_permissions.',4,2),(60,'2018-05-13 16:53:19','4','proyectos-eie',1,'',4,2),(61,'2018-05-16 00:22:57','3','anovello',2,'Modifica password.',4,2),(62,'2018-05-16 00:24:16','3','anovello',2,'Modifica is_staff.',4,2),(63,'2018-05-16 00:26:00','3','anovello',2,'Modifica is_superuser.',4,2),(64,'2018-05-16 00:27:31','45','Soraiz Ana Paula',1,'',8,2),(65,'2018-05-16 00:28:10','23','Feroldi Diego',1,'',9,2),(66,'2018-05-16 00:32:39','6','Sistema de Gestión Energia para Microredes Inteligentes - Romero Mónica',1,'',10,2),(67,'2018-05-21 22:31:23','24','Migoni Gustavo',1,'',9,2),(68,'2018-05-21 22:32:12','25','Nacusse Matías',1,'',9,2),(69,'2018-05-21 22:32:52','7','control de trayectoria para navegación autónoma de robot móvil con plataform omniwhell - Nacusse Matías',1,'',10,2),(70,'2018-05-21 22:43:55','8','Medición de respuesta al impulso y su aplicación a un plugin de reververación - Miyara Federico',1,'',10,2),(71,'2018-05-21 23:01:10','46','Mujica martín',1,'',8,2),(72,'2018-05-21 23:02:16','26','Kofman Ernesto',1,'',9,2),(73,'2018-05-21 23:03:25','9','Desarrollo e implementacón de un sistema de sensado y posicionamiento en prototipo de robot desmalezador - Kofman Ernesto',1,'',10,2),(74,'2018-05-21 23:05:31','47','Carlachiani Giuliano',1,'',8,2),(75,'2018-05-21 23:07:20','10','Dispositivo para la calibración de herramientas de control para interruptores diferenciales - Geninatti Sergio',1,'',10,2),(76,'2018-05-29 22:36:06','27','Venturini Eduardo',1,'',9,2),(77,'2018-05-29 22:38:41','11','Generador de pulsos para estimulación del corazón - Venturini Eduardo',1,'',10,2),(78,'2018-05-29 22:41:03','48','Escudero Luciano Alejo',1,'',8,2),(79,'2018-05-29 22:42:34','11','Generador de pulsos para estimulación del corazón - Venturini Eduardo',2,'Modifica alumnos.',10,2),(80,'2018-05-29 22:48:33','49','Cordi Luciano',1,'',8,2),(81,'2018-05-29 22:49:31','50','Rolón Fabricio',1,'',8,2),(82,'2018-05-29 22:52:59','12','Formalización y especificación para el desarrollo de un UAV - Geninatti Sergio',1,'',10,2),(83,'2018-05-29 22:55:34','13','Emulador digital de amplificadores y efectos para guitarra - Miyara Federico',1,'',10,2),(84,'2018-05-29 22:56:47','13','Emulador digital de amplificadores y efectos para guitarra - Miyara Federico',2,'Modifica orientacion.',10,2),(85,'2018-05-29 22:59:07','28','Coronel José',1,'',9,2),(86,'2018-05-29 23:00:11','14','Implemetnación de una red LORaWAN - Coronel José',1,'',10,2),(87,'2018-05-29 23:04:01','51','Pellegrino Adrián',1,'',8,2),(88,'2018-05-29 23:05:15','3','Desarrollo de Instrumentos Digitales de posición aeronáutica - Gentile Aldo',2,'Modifica titulo y orientacion.',10,2),(89,'2018-05-29 23:08:05','11','Generador de pulsos para estimulación del corazón - Venturini Eduardo',2,'Modifica asesor.',10,2),(90,'2018-06-05 00:23:02','52','Di Rosa Franco',1,'',8,2),(91,'2018-06-05 00:24:17','53','Collazuol Luis',1,'',8,2),(92,'2018-06-05 00:28:03','29','Amoedo Pablo',1,'',9,2),(93,'2018-06-05 00:29:40','15','Sistema basado en un tubo de impedancia para cacterización acústica de un material - Miyara Federico',1,'',10,2),(94,'2018-06-06 18:59:14','1','nuevo-2014',1,'',11,2),(95,'2018-06-06 18:59:36','12','Formalización y especificación para el desarrollo de un UAV - Geninatti Sergio',2,'Modifica plan.',10,2),(96,'2018-06-06 19:00:23','11','Generador de pulsos para estimulación del corazón - Venturini Eduardo',2,'Modifica plan.',10,2),(97,'2018-06-06 19:01:20','7','control de trayectoria para navegación autónoma de robot móvil con plataform omniwhell - Nacusse Matías',2,'Modifica plan.',10,2),(98,'2018-06-06 19:02:13','3','Desarrollo de Instrumentos Digitales de posición aeronáutica - Gentile Aldo',2,'Modifica plan.',10,2),(99,'2018-06-06 19:02:34','2','Comunicación VX2: estudio e implementación del protocolo IEEE802.11p utilizando tecnologia de Radio Definida por Software  (SDR) - Iglesias Natalia',2,'Modifica plan.',10,2),(100,'2018-06-06 19:02:59','8','Medición de respuesta al impulso y su aplicación a un plugin de reververación - Miyara Federico',2,'Modifica plan.',10,2),(101,'2018-06-06 19:03:15','14','Implemetnación de una red LORaWAN - Coronel José',2,'Modifica plan.',10,2),(102,'2018-06-06 19:03:29','13','Emulador digital de amplificadores y efectos para guitarra - Miyara Federico',2,'Modifica plan.',10,2),(103,'2018-06-06 19:17:07','30','test test',1,'',9,2),(104,'2018-06-06 19:17:48','54','test1 test1',1,'',8,2),(105,'2018-06-06 19:18:27','1','Prueba - test test',2,'Modifica director.',10,2),(106,'2018-06-06 19:18:46','1','Prueba - test test',2,'No ha modificado ningún campo.',10,2),(107,'2018-07-31 22:00:36','55','Luque María Florencia',1,'',8,2),(108,'2018-07-31 22:01:21','31','Luque adrian',1,'',9,2),(109,'2018-07-31 22:14:20','2','plan viejo',1,'',11,2),(110,'2018-07-31 22:14:41','3','plan viejo',1,'',11,2),(111,'2018-07-31 22:16:34','16','Implementación de un sistema de comunicación utilizando - Mare Renzo',1,'',10,2),(112,'2018-07-31 22:26:14','56','mugna emanuel',1,'',8,2),(113,'2018-07-31 22:27:36','32','Miyara Federico',1,'',9,2),(114,'2018-07-31 22:28:47','17','Desarrollo e implementación de efecto de guitarra en tiempo real - Miyara Federico',1,'',10,2),(115,'2018-07-31 22:29:07','33','Sad Gonzalo',1,'',9,2),(116,'2018-07-31 22:29:25','17','Desarrollo e implementación de efecto de guitarra en tiempo real - Sad Gonzalo',2,'Modifica director.',10,2),(117,'2018-07-31 22:49:05','57','Grippo Lucas',1,'',8,2),(118,'2018-07-31 22:51:56','58','Moya Ignacio',1,'',8,2),(119,'2018-07-31 22:54:18','18','demoludador/decodificador HRD para recepción de imágenes satelitales - Arraigada Fernando',1,'',10,2),(120,'2018-07-31 22:55:44','18','demoludador/decodificador HRD para recepción de imágenes satelitales - Arraigada Fernando',2,'No ha modificado ningún campo.',10,2),(121,'2018-08-14 21:59:14','17','Desarrollo e implementación de efecto de guitarra en tiempo real - Sad Gonzalo',2,'Modifica alumnos.',10,2),(122,'2018-08-14 22:08:58','34',' Ezpeleta Joaquin',1,'',9,2),(123,'2018-08-14 22:10:24','19','Implementación de una capa de comunicación CAN para una micro-red electrica intelligente -  Ezpeleta Joaquin',1,'',10,2),(124,'2018-08-14 22:11:10','19','Implementación de una capa de comunicación CAN para una micro-red electrica intelligente -  Ezpeleta Joaquin',2,'Modifica orientacion.',10,2),(125,'2018-08-14 22:19:42','18','demoludador/decodificador HRD para recepción de imágenes satelitales - Arraigada Fernando',2,'Modifica alumnos y asesor.',10,2),(126,'2018-08-14 23:42:02','18','demoludador/decodificador HRD para recepción de imágenes satelitales - Arraigada Fernando',2,'Modifica alumnos y asesor.',10,2),(127,'2018-08-14 23:43:30','16','Implementación de un sistema de comunicación utilizando VLC - Mare Renzo',2,'Modifica titulo y alumnos.',10,2),(128,'2018-08-28 23:09:37','3','Desarrollo de Instrumentos Digitales de posición aeronáutica - Gentile Aldo',2,'Modifica fecha_anteproyecto.',10,2),(129,'2018-08-28 23:11:26','2','Comunicación VX2: estudio e implementación del protocolo IEEE802.11p utilizando tecnologia de Radio Definida por Software  (SDR) - Iglesias Natalia',2,'Modifica fecha_anteproyecto.',10,2),(130,'2018-10-09 22:42:18','19','Implementación de una capa de comunicación CAN para una micro-red electrica intelligente -  Ezpeleta Joaquin',2,'Modifica fecha_anteproyecto.',10,2),(131,'2018-10-09 23:03:26','20','Rectificador - Romero Mónica',1,'',10,2),(132,'2018-10-09 23:24:54','12','Formalización y especificación para el desarrollo de un UAV - Geninatti Sergio',2,'Modifica fecha_anteproyecto.',10,2),(133,'2018-10-09 23:33:20','7','control de trayectoria para navegación autónoma de robot móvil con plataform omniwheel - Nacusse Matías',2,'Modifica titulo.',10,2),(134,'2018-10-22 23:31:34','9','Desarrollo e implementacón de un sistema de sensado y posicionamiento en prototipo de robot desmalezador - Kofman Ernesto',2,'Modifica fecha_anteproyecto.',10,2),(135,'2018-10-22 23:39:45','21','Diseño e implementación de firmware para un rectificador trifáscio controlado PWM con fines didácticos - Romero Mónica',1,'',10,2),(136,'2018-10-22 23:40:58','7','control de trayectoria para navegación autónoma de robot móvil con plataform omniwheel - Nacusse Matías',2,'Modifica fecha_anteproyecto.',10,2),(137,'2018-10-29 23:25:57','8','Medición de respuesta al impulso y su aplicación a un plugin de reverberación - Miyara Federico',2,'Modifica titulo y fecha_anteproyecto.',10,2),(138,'2018-10-29 23:32:28','20','Rectificador - Romero Mónica',2,'Modifica fecha_anteproyecto.',10,2),(139,'2018-10-29 23:34:32','20','Rectificador - Romero Mónica',3,'',10,2),(140,'2018-10-29 23:37:01','19','Implementación de una capa de comunicación CAN para una micro-red electrica intelligente -  Ezpeleta Joaquin',2,'Modifica plan.',10,2),(141,'2018-11-07 15:35:27','14','Implemetnación de una red LORaWAN - Coronel José',2,'Modifica fecha_anteproyecto.',10,2),(142,'2018-11-07 15:38:37','4','plan 2014-v2019',1,'',11,2),(143,'2018-11-07 15:39:05','1','plan2014-v2018',2,'Modifica nombre.',11,2),(144,'2018-11-27 22:50:09','35','Luppi Patricio',1,'',9,2),(145,'2018-11-27 22:50:56','22','sistema automatizado para la identificación, selección y clasficación de piezas discriminadas según el color - Luppi Patricio',1,'',10,2),(146,'2018-12-19 21:30:21','2','Comunicación VX2: estudio e implementación del protocolo IEEE802.11p utilizando tecnologia de Radio Definida por Software  (SDR) - Iglesias Natalia',2,'Modifica fecha_final.',10,2),(147,'2018-12-19 21:31:19','22','sistema automatizado para la identificación, selección y clasficación de piezas discriminadas según el color - Luppi Patricio',2,'Modifica fecha_anteproyecto.',10,2),(148,'2018-12-19 21:43:46','23','Prototipo de robot delta para la manupulación automática de objetos mediante visón por computadora - Gomez Juan Carlos',1,'',10,2),(149,'2018-12-19 21:44:13','36','Terissi Lucas',1,'',9,2),(150,'2018-12-19 21:44:35','23','Prototipo de robot delta para la manupulación automática de objetos mediante visón por computadora - Terissi Lucas',2,'Modifica director.',10,2),(151,'2018-12-19 21:49:42','24','Desarrollo e implementación de funciones de navegación autónoma para un prototipo de robto desmalezador - Kofman Ernesto',1,'',10,2),(152,'2018-12-19 21:53:52','23','Prototipo de robot delta para la manupulación automática de objetos mediante visón por computadora - Terissi Lucas',2,'Modifica fecha_inscripcion.',10,2),(153,'2019-03-18 13:00:06','9','control 2019',1,'[{\"added\": {}}]',7,2),(154,'2019-03-18 13:00:18','10','digital 2019',1,'[{\"added\": {}}]',7,2),(155,'2019-03-18 13:00:30','11','comunicaciones 2019',1,'[{\"added\": {}}]',7,2),(156,'2019-03-18 13:01:41','59','Álvarez Julián',2,'[{\"changed\": {\"fields\": [\"orientacion\"]}}]',8,2),(157,'2019-03-18 13:02:29','64','Maia Melisa Andali',2,'[{\"changed\": {\"fields\": [\"apellido\", \"email\", \"orientacion\"]}}]',8,2),(158,'2019-03-18 13:02:51','60','Arroyo Jonatan',2,'[{\"changed\": {\"fields\": [\"orientacion\"]}}]',8,2),(159,'2019-03-18 13:03:17','61','Ascolani Guillermo',2,'[{\"changed\": {\"fields\": [\"orientacion\"]}}]',8,2),(160,'2019-03-18 13:03:49','65','Ariel Jordán Baruzzo',2,'[{\"changed\": {\"fields\": [\"apellido\", \"orientacion\"]}}]',8,2),(161,'2019-03-18 13:04:18','66','Lucas Alejandro Bolzani',2,'[{\"changed\": {\"fields\": [\"apellido\", \"orientacion\"]}}]',8,2),(162,'2019-03-18 13:04:58','67','Guillermo Brauchli',2,'[{\"changed\": {\"fields\": [\"apellido\", \"email\", \"orientacion\"]}}]',8,2),(163,'2019-03-18 13:08:11','68','Jeremías Tomás Cruz',2,'[{\"changed\": {\"fields\": [\"apellido\", \"orientacion\"]}}]',8,2),(164,'2019-03-18 13:09:04','81','Tomás Ayi',2,'[{\"changed\": {\"fields\": [\"apellido\", \"orientacion\"]}}]',8,2),(165,'2019-03-18 13:11:46','100','Luciano Antonio Buono',2,'[{\"changed\": {\"fields\": [\"apellido\", \"legajo\", \"orientacion\"]}}]',8,2),(166,'2019-03-18 13:14:42','83','Nicolás Roberto Bazzano',2,'[{\"changed\": {\"fields\": [\"apellido\", \"orientacion\"]}}]',8,2),(167,'2019-03-18 13:16:59','62','Cerliani (NO CLASE) Alex',2,'[{\"changed\": {\"fields\": [\"apellido\", \"orientacion\"]}}]',8,2),(168,'2019-03-18 13:19:02','112','Ezequiel colman (NO CLASE)',1,'[{\"added\": {}}]',8,2),(169,'2019-03-18 13:20:41','85','Ián Chaya (NO CLASE)',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\", \"orientacion\"]}}]',8,2),(170,'2019-03-18 13:22:11','86','Emanuel Cima',2,'[{\"changed\": {\"fields\": [\"apellido\", \"orientacion\"]}}]',8,2),(171,'2019-03-18 13:23:23','84','Lisandro Ariel Cesaratto',2,'[{\"changed\": {\"fields\": [\"apellido\", \"orientacion\"]}}]',8,2),(172,'2019-03-18 13:24:07','87','Felipe Cinto',2,'[{\"changed\": {\"fields\": [\"apellido\", \"orientacion\"]}}]',8,2),(173,'2019-03-18 13:25:40','69','Sebastián David Danura',2,'[{\"changed\": {\"fields\": [\"apellido\", \"orientacion\"]}}]',8,2),(174,'2019-03-18 13:26:03','85','Ián Chaya',2,'[{\"changed\": {\"fields\": [\"nombre\"]}}]',8,2),(175,'2019-03-18 13:27:40','17','Folmer (NO CLASE) Fernando',2,'[{\"changed\": {\"fields\": [\"apellido\", \"legajo\"]}}]',8,2),(176,'2019-03-18 13:28:36','112','Ezequiel (NO CLASE) colman',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\"]}}]',8,2),(177,'2019-03-18 13:29:21','89','Julián Gómez',2,'[{\"changed\": {\"fields\": [\"apellido\", \"orientacion\"]}}]',8,2),(178,'2019-03-18 13:30:32','20','Isaia (NO CLASE) Guillermo',2,'[{\"changed\": {\"fields\": [\"apellido\", \"orientacion\"]}}]',8,2),(179,'2019-03-18 13:31:17','90','Kevin Claudio Kegalj',2,'[{\"changed\": {\"fields\": [\"apellido\", \"orientacion\"]}}]',8,2),(180,'2019-03-18 13:31:59','70','Lucas Emanuel Lastorta',2,'[{\"changed\": {\"fields\": [\"apellido\", \"orientacion\"]}}]',8,2),(181,'2019-03-18 13:33:08','73','Mandrile (NO CLASE) Nicolas',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\"]}}]',8,2),(182,'2019-03-18 13:34:10','75','Guillermo Nicolás Martin',2,'[{\"changed\": {\"fields\": [\"apellido\", \"orientacion\"]}}]',8,2),(183,'2019-03-18 13:36:00','24','Monteros Gavriloff (NO CLASE) Lucio',2,'[{\"changed\": {\"fields\": [\"apellido\", \"legajo\", \"orientacion\"]}}]',8,2),(184,'2019-03-18 13:37:08','103','Medina Pedreira (NO CLASE) José Luis',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\", \"legajo\", \"orientacion\"]}}]',8,2),(185,'2019-03-18 13:38:30','104','Diego Gabriel Mussolini',2,'[{\"changed\": {\"fields\": [\"apellido\", \"legajo\", \"orientacion\"]}}]',8,2),(186,'2019-03-18 13:39:22','77','Podoroska IVAN',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\", \"orientacion\"]}}]',8,2),(187,'2019-03-18 13:40:31','91','Parisi Lucas Mariano',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\", \"orientacion\"]}}]',8,2),(188,'2019-03-18 13:41:16','92','Perugini Roldan Luciano Nahuel',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\", \"orientacion\"]}}]',8,2),(189,'2019-03-18 13:42:09','95','Rodriguez (NO CLASE) Rodriguez  Pablo Joel',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\", \"orientacion\"]}}]',8,2),(190,'2019-03-18 13:42:46','94','Reyes Facundo Tomas',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\", \"orientacion\"]}}]',8,2),(191,'2019-03-18 13:43:38','78','Raimundo Joaquín',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\", \"orientacion\"]}}]',8,2),(192,'2019-03-18 13:44:35','36','Simich Esteban',3,'',8,2),(193,'2019-03-18 13:44:59','108','Simich Esteban',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\", \"legajo\", \"orientacion\"]}}]',8,2),(194,'2019-03-18 13:45:53','107','Scoccimarra Franco Agustín',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\", \"legajo\", \"orientacion\"]}}]',8,2),(195,'2019-03-18 13:46:21','108','Simich (NO CLASE) Esteban',2,'[{\"changed\": {\"fields\": [\"apellido\"]}}]',8,2),(196,'2019-03-18 13:47:10','96','Sarina Diego',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\", \"orientacion\"]}}]',8,2),(197,'2019-03-18 13:47:57','113','Sola Francisco',1,'[{\"added\": {}}]',8,2),(198,'2019-03-18 13:49:31','79','Seguezzo Franco Nahuel',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\", \"orientacion\"]}}]',8,2),(199,'2019-03-18 13:51:57','37','Vazquez (NO CLASE) Martin',2,'[{\"changed\": {\"fields\": [\"apellido\", \"orientacion\"]}}]',8,2),(200,'2019-03-18 13:53:27','114','Medina Mauro',1,'[{\"added\": {}}]',8,2),(201,'2019-03-18 13:58:36','71','Leonardo Lucci',2,'[{\"changed\": {\"fields\": [\"apellido\", \"orientacion\"]}}]',8,2),(202,'2019-03-18 14:02:51','81','Ayi (NO CLASE) Tomas',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\"]}}]',8,2),(203,'2019-03-18 14:03:54','85','Chaya (NO clase) Ian',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\"]}}]',8,2),(204,'2019-03-18 19:35:24','98',' Augusto Depetris',3,'',8,2),(205,'2019-03-18 19:35:48','85','Chaya (NO clase) Ian',3,'',8,2),(206,'2019-03-22 22:56:04','25','Diseño de un sistema de locomoción para un robot cuadrúpedo - Nacusse Matías',1,'[{\"added\": {}}]',10,2),(207,'2019-03-25 22:05:12','17','Desarrollo e implementación de efecto de guitarra en tiempo real - Sad Gonzalo',2,'[{\"changed\": {\"fields\": [\"fecha_anteproyecto\"]}}]',10,2),(208,'2019-03-26 22:16:32','26','Diseño de un sistema de automatización de para el proceso de producción de cerveza a pequeña escala - Novello Armando',1,'[{\"added\": {}}]',10,2),(209,'2019-04-01 21:22:15','115','Zoppi juan Pablo',1,'[{\"added\": {}}]',8,2),(216,'2019-04-02 15:59:32','1','cgallo',2,'[{\"changed\": {\"fields\": [\"username\", \"first_name\", \"last_name\", \"email\"]}}]',4,1),(217,'2019-04-02 15:59:48','4','proyectos-eie',3,'',4,1),(218,'2019-04-03 18:09:51','16','Implementación de un sistema de comunicación utilizando VLC - Mare Renzo',2,'[{\"changed\": {\"fields\": [\"plan\"]}}]',10,2),(219,'2019-04-03 18:10:08','15','Sistema basado en un tubo de impedancia para cacterización acústica de un material - Miyara Federico',2,'[{\"changed\": {\"fields\": [\"plan\"]}}]',10,2),(220,'2019-04-03 18:10:32','10','Dispositivo para la calibración de herramientas de control para interruptores diferenciales - Geninatti Sergio',2,'[{\"changed\": {\"fields\": [\"plan\"]}}]',10,2),(221,'2019-04-03 18:11:39','1','Prueba - test test',3,'',10,2),(222,'2019-04-03 18:45:05','6','Sistema de Gestión Energia para Microredes Inteligentes - Romero Mónica',2,'[{\"changed\": {\"fields\": [\"plan\"]}}]',10,2),(223,'2019-04-23 21:33:55','29','Automatización del control de las etapas de fermentación, maduración y clarificado del proceso de elaboración de cerveza artesanal - Pastelleto Sergio',1,'[{\"added\": {}}]',10,2),(224,'2019-04-23 21:34:38','77','Podoroska Ivan',2,'[{\"changed\": {\"fields\": [\"nombre\"]}}]',8,2),(225,'2019-04-23 21:35:36','29','Automatización del control de las etapas de fermentación, maduración y clarificado del proceso de elaboración de cerveza artesanal - Pastelleto Sergio',2,'[{\"changed\": {\"fields\": [\"orientacion\"]}}]',10,2),(226,'2019-04-23 22:52:37','30','sistema de control para cultivo hidropónico - Gentile Aldo',1,'[{\"added\": {}}]',10,2),(227,'2019-04-23 22:54:28','116','Chaya Joel',1,'[{\"added\": {}}]',8,2),(228,'2019-04-23 22:54:53','30','sistema de control para cultivo hidropónico - Gentile Aldo',2,'[{\"changed\": {\"fields\": [\"alumnos\"]}}]',10,2),(229,'2019-04-29 21:33:07','31','diseño e implementación de hardware y software de control de un manipulador robótico de tipo industrial - Nacusse Matías',1,'[{\"added\": {}}]',10,2),(230,'2019-05-06 23:06:09','37','Minunucci Gustavo',1,'[{\"added\": {}}]',9,2),(231,'2019-05-06 23:07:25','32','Dinamómetro inercial - Minunucci Gustavo',1,'[{\"added\": {}}]',10,2),(232,'2019-05-13 18:05:45','33','prototipo a escala de un vehiculo autónomo para logística en almacén industrial - Sad Gonzalo',1,'[{\"added\": {}}]',10,2),(233,'2019-05-13 18:08:07','30','sistema de control para cultivo hidropónico - Gentile Aldo',2,'[{\"changed\": {\"fields\": [\"plan\"]}}]',10,2),(234,'2019-05-13 18:08:26','29','Automatización del control de las etapas de fermentación, maduración y clarificado del proceso de elaboración de cerveza artesanal - Pastelleto Sergio',2,'[{\"changed\": {\"fields\": [\"plan\"]}}]',10,2),(235,'2019-05-13 18:08:50','31','diseño e implementación de hardware y software de control de un manipulador robótico de tipo industrial - Nacusse Matías',2,'[{\"changed\": {\"fields\": [\"plan\"]}}]',10,2),(236,'2019-05-20 23:52:32','34','Diseño y desarrollo de un anemómetro ultrasónico sin partes móviles - Minunucci Gustavo',1,'[{\"added\": {}}]',10,2),(239,'2019-06-05 18:52:57','28','prueba',3,'',10,1),(240,'2019-06-11 23:36:25','35','telemedición de tanques de combustble - Gentile Aldo',1,'[{\"added\": {}}]',10,2),(241,'2019-06-11 23:37:01','38','Hendrik Lionel',1,'[{\"added\": {}}]',9,2),(242,'2019-06-11 23:37:46','35','telemedición de tanques de combustble - Hendrik Lionel',2,'[{\"changed\": {\"fields\": [\"director\", \"fecha_inscripcion\"]}}]',10,2),(243,'2019-06-18 23:23:45','33','prototipo a escala de un vehiculo autónomo para logística en almacén industrial - Sad Gonzalo',2,'[{\"changed\": {\"fields\": [\"orientacion\"]}}]',10,2),(244,'2019-06-24 21:22:29','93','Peñas Jeremias',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\"]}}]',8,2),(245,'2019-06-24 21:23:19','109','Toribio Esteban',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\", \"legajo\"]}}]',8,2),(246,'2019-06-24 21:24:12','97','Carnevale Ignacio',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\"]}}]',8,2),(247,'2019-06-24 21:25:07','100','Buono Luciano Antonio',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\"]}}]',8,2),(248,'2019-06-24 21:26:14','104','Mussolini Diego Gabriel',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\"]}}]',8,2),(249,'2019-06-24 21:27:07','101','Centurion German Agustin',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\", \"legajo\"]}}]',8,2),(250,'2019-06-24 21:28:30','90','Kegalj Kevin Claudio',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\"]}}]',8,2),(251,'2019-06-24 21:29:44','89','Gómez Julian',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\"]}}]',8,2),(252,'2019-06-24 22:25:23','111','Unno Santiago',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\"]}}]',8,2),(253,'2019-06-24 22:26:04','106','Raveglia Martín',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\", \"legajo\"]}}]',8,2),(254,'2019-06-24 22:26:50','110','Vasquez Martin Sebastian',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\", \"legajo\"]}}]',8,2),(255,'2019-06-24 22:27:28','105','Pizzarello Agustín',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\", \"legajo\"]}}]',8,2),(256,'2019-06-24 22:28:02','95','Rodriguez (NO CLASE) Pablo Joel',2,'[{\"changed\": {\"fields\": [\"nombre\"]}}]',8,2),(257,'2019-06-24 22:28:43','88','Diaz Paula Marcela',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\"]}}]',8,2),(258,'2019-06-24 22:31:35','87','Cinto Felipe',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\"]}}]',8,2),(259,'2019-06-24 22:32:16','86','Cima Emanuel',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\"]}}]',8,2),(260,'2019-06-24 22:33:07','84','Cesaratto Lisandro Ariel',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\"]}}]',8,2),(261,'2019-06-24 22:33:57','83','Bazzano Nicolas Roberto',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\"]}}]',8,2),(262,'2019-06-24 22:36:14','70','Lastorta Lucas Emanuel',2,'[{\"changed\": {\"fields\": [\"nombre\", \"apellido\"]}}]',8,2),(263,'2019-06-25 23:17:07','32','Dinamómetro inercial para motores de combustíon interna - Minunucci Gustavo',2,'[{\"changed\": {\"fields\": [\"titulo\", \"fecha_anteproyecto\"]}}]',10,2),(264,'2019-06-25 23:20:34','36','Diseño construcción e implementación de una plataforma móvil con dos sistemas de locomoción y sus respectivos sistema de control - Nacusse Matías',1,'[{\"added\": {}}]',10,2),(265,'2019-06-25 23:22:39','39','Crespo Martín Andres',1,'[{\"added\": {}}]',9,2),(266,'2019-06-25 23:23:22','36','Diseño construcción e implementación de una plataforma móvil con dos sistemas de locomoción y sus respectivos sistema de control - Nacusse Matías',2,'[{\"changed\": {\"fields\": [\"asesor\"]}}]',10,2),(267,'2019-07-22 21:43:35','19','Implementación de una capa de comunicación CAN para una micro-red electrica intelligente -  Ezpeleta Joaquin',2,'[{\"changed\": {\"fields\": [\"fecha_final\"]}}]',10,2),(268,'2019-07-22 21:59:41','37','control y adquisición de datos de temperatura en fermentadores de cerveza Industriales - Novello Armando',1,'[{\"added\": {}}]',10,2),(269,'2019-07-22 22:00:46','37','control y adquisición de datos de temperatura en fermentadores de cerveza Industriales - Novello Armando',2,'[{\"changed\": {\"fields\": [\"orientacion\", \"plan\"]}}]',10,2),(270,'2019-07-23 23:25:53','13','Emulador digital de amplificadores y efectos para guitarra - Miyara Federico',2,'[{\"changed\": {\"fields\": [\"fecha_anteproyecto\"]}}]',10,2),(271,'2019-08-05 12:46:32','8','Cavalieri Juan Ignacio',2,'[{\"changed\": {\"fields\": [\"nombre\"]}}]',8,2),(272,'2019-08-05 13:00:30','3','Control 2018',2,'[{\"changed\": {\"fields\": [\"descripcion\"]}}]',7,2),(273,'2019-08-05 13:01:06','4','Digital 2018',2,'[{\"changed\": {\"fields\": [\"descripcion\"]}}]',7,2),(274,'2019-08-05 13:01:27','2','Comunicaciones 2018',2,'[{\"changed\": {\"fields\": [\"descripcion\"]}}]',7,2),(275,'2019-08-05 13:01:42','6','Diseño electrónico 2018',2,'[{\"changed\": {\"fields\": [\"descripcion\"]}}]',7,2),(276,'2019-08-09 17:43:40','33','prototipo a escala de un vehiculo autónomo para logística en almacén industrial - Sad Gonzalo',2,'[{\"changed\": {\"fields\": [\"fecha_anteproyecto\"]}}]',10,2),(277,'2019-08-21 14:51:45','14','Implemetnación de una red LORaWAN - Coronel José',2,'[{\"changed\": {\"fields\": [\"fecha_final\"]}}]',10,2),(278,'2019-08-26 21:49:50','54','test1 test1',3,'',8,2),(279,'2019-09-03 21:56:35','38','desarrollo e implementación del control del sistema de pulverización de herbicida para un prototipo de robot desmalezador - Kofman Ernesto',1,'[{\"added\": {}}]',10,2),(280,'2019-09-18 14:30:44','17','Desarrollo e implementación de efecto de guitarra en tiempo real - Sad Gonzalo',2,'[{\"changed\": {\"fields\": [\"fecha_final\"]}}]',10,2),(281,'2019-09-18 14:31:08','34','Diseño y desarrollo de un anemómetro ultrasónico sin partes móviles - Minunucci Gustavo',2,'[{\"changed\": {\"fields\": [\"fecha_anteproyecto\"]}}]',10,2),(282,'2019-10-07 03:01:48','6','Sistema de Gestión Energia para Microredes Inteligentes - Romero Mónica',2,'[{\"changed\": {\"fields\": [\"fecha_final\"]}}]',10,2),(283,'2019-10-16 23:43:27','26','Diseño de un sistema de automatización de para el proceso de producción de cerveza a pequeña escala - Novello Armando',3,'',10,2),(284,'2019-10-16 23:46:29','38','desarrollo e implementación del control del sistema de pulverización de herbicida para un prototipo de robot desmalezador - Kofman Ernesto',2,'[{\"changed\": {\"fields\": [\"fecha_anteproyecto\"]}}]',10,2),(285,'2019-10-22 21:56:10','39','Sistema de monitoreo de circulación de bicilcetas a través de procesamiento de imágenes - Gomez Juan Carlos',1,'[{\"added\": {}}]',10,2),(286,'2019-10-22 21:56:53','40','Del Colle Franco',1,'[{\"added\": {}}]',9,2),(287,'2019-10-22 21:57:35','39','Sistema de monitoreo de circulación de bicilcetas a través de procesamiento de imágenes - Del Colle Franco',2,'[{\"changed\": {\"fields\": [\"director\", \"asesor\", \"orientacion\"]}}]',10,2),(288,'2019-10-22 22:05:36','40','desarrollo e implementación de un sistema de almacenamiento de energía basado en supercapacitores con aplicaciónen una smart grid - Alba Daniel',1,'[{\"added\": {}}]',10,2),(289,'2019-10-22 22:15:22','113','Sola Francisco',2,'[{\"changed\": {\"fields\": [\"orientacion\"]}}]',8,2),(290,'2019-10-22 22:16:24','117','Abt Juan Francisco',1,'[{\"added\": {}}]',8,2),(291,'2019-10-22 22:16:47','117','Abt Juan Francisco',2,'[{\"changed\": {\"fields\": [\"orientacion\"]}}]',8,2),(292,'2019-10-22 22:19:00','40','desarrollo e implementación de un sistema de almacenamiento de energía basado en supercapacitores con aplicaciónen una smart grid - Alba Daniel',2,'[{\"changed\": {\"fields\": [\"alumnos\", \"orientacion\", \"fecha_inscripcion\"]}}]',10,2),(293,'2019-10-22 23:48:35','118','Derman Diego',1,'[{\"added\": {}}]',8,2),(294,'2019-10-22 23:50:55','41','sistema automatizado para el reconocimiento de baches mediante cámara estereo - Sad Gonzalo',1,'[{\"added\": {}}]',10,2),(295,'2019-10-22 23:51:19','39','Sistema de monitoreo de circulación de bicilcetas a través de procesamiento de imágenes - Del Colle Franco',2,'[{\"changed\": {\"fields\": [\"plan\"]}}]',10,2),(296,'2019-10-29 22:06:28','12','Formalización y especificación para el desarrollo de un UAV - Geninatti Sergio',2,'[{\"changed\": {\"fields\": [\"fecha_final\"]}}]',10,2),(297,'2019-10-29 23:36:49','41','sistema automatizado para el reconocimiento de baches mediante cámara estereo - Sad Gonzalo',2,'[{\"changed\": {\"fields\": [\"orientacion\"]}}]',10,2),(298,'2019-11-04 21:20:03','41','sistema automatizado para el reconocimiento de baches mediante cámara estereo - Sad Gonzalo',2,'[{\"changed\": {\"fields\": [\"fecha_anteproyecto\"]}}]',10,2),(299,'2019-11-12 00:05:56','24','Desarrollo e implementación de funciones de navegación autónoma para un prototipo de robto desmalezador - Sad Gonzalo',2,'[{\"changed\": {\"fields\": [\"director\"]}}]',10,2),(300,'2019-11-12 00:18:29','24','Desarrollo e implementación de funciones de navegación autónoma para un prototipo de robto desmalezador - Migoni Gustavo',2,'[{\"changed\": {\"fields\": [\"director\"]}}]',10,2),(301,'2019-11-25 23:43:00','23','Prototipo de robot delta para la manupulación automática de objetos mediante visón por computadora - Terissi Lucas',2,'[{\"changed\": {\"fields\": [\"fecha_final\"]}}]',10,2),(302,'2019-11-26 16:03:25','7','control de trayectoria para navegación autónoma de robot móvil con plataform omniwheel - Nacusse Matías',2,'[{\"changed\": {\"fields\": [\"fecha_final\"]}}]',10,2),(303,'2019-12-02 22:31:38','36','Diseño construcción e implementación de una plataforma móvil con dos sistemas de locomoción y sus respectivos sistema de control - Nacusse Matías',2,'[{\"changed\": {\"fields\": [\"fecha_anteproyecto\"]}}]',10,2),(304,'2019-12-10 18:40:49','42','sistema de seguimiento de trayectorias para vehiculos sobreactivados con tolrencia a fallas - Gentile Aldo',1,'[{\"added\": {}}]',10,2),(305,'2019-12-10 18:42:25','41','Nacusse Matías',1,'[{\"added\": {}}]',9,2),(306,'2019-12-10 18:43:21','42','stollte Torben',1,'[{\"added\": {}}]',9,2),(307,'2019-12-10 18:44:29','42','sistema de seguimiento de trayectorias para vehiculos sobreactivados con tolrencia a fallas - Nacusse Matías',2,'[{\"changed\": {\"fields\": [\"director\", \"co_director\"]}}]',10,2),(308,'2019-12-17 21:35:46','3','Desarrollo de Instrumentos Digitales de posición aeronáutica - Gentile Aldo',2,'[{\"changed\": {\"fields\": [\"fecha_final\"]}}]',10,2),(309,'2020-02-11 20:35:18','40','desarrollo e implementación de un sistema de almacenamiento de energía basado en supercapacitores con aplicaciónen una smart grid - Alba Daniel',2,'[{\"changed\": {\"fields\": [\"fecha_anteproyecto\"]}}]',10,2),(310,'2020-02-18 21:47:26','29','Automatización del control de las etapas de fermentación, maduración y clarificado del proceso de elaboración de cerveza artesanal - Pastelleto Sergio',2,'[{\"changed\": {\"fields\": [\"fecha_anteproyecto\"]}}]',10,2),(311,'2020-02-20 18:06:00','18','demoludador/decodificador HRD para recepción de imágenes satelitales - Arraigada Fernando',2,'[{\"changed\": {\"fields\": [\"fecha_final\"]}}]',10,2),(312,'2020-02-20 18:24:34','43','Equipo de Biofeedback EMG Portátil - Gentile Aldo',1,'[{\"added\": {}}]',10,2),(313,'2020-02-20 19:36:26','119','Santos Lucio',1,'[{\"added\": {}}]',8,2),(314,'2020-02-20 19:36:52','25','Moya Martin',2,'[{\"changed\": {\"fields\": [\"email\"]}}]',8,2),(315,'2020-02-20 19:38:10','120','Cecarelli Federico',1,'[{\"added\": {}}]',8,2),(316,'2020-02-20 19:41:34','44','Estudio e implementación de un sistema de alimentación de baterias Li-Ion de baja y mediana potencia - Romero Mónica',1,'[{\"added\": {}}]',10,2),(317,'2020-02-20 19:42:04','12','plan viejo -plan nuevo (mix alumnos)',1,'[{\"added\": {}}]',7,2),(318,'2020-02-20 19:42:38','43','Arnejo Bichi',1,'[{\"added\": {}}]',9,2),(319,'2020-02-20 19:43:35','44','Estudio e implementación de un sistema de alimentación de baterias Li-Ion de baja y mediana potencia - Romero Mónica',2,'[{\"changed\": {\"fields\": [\"asesor\"]}}]',10,2),(320,'2020-02-20 19:44:09','5','plan viejo -plan nuevo (Mix de alumnos)',1,'[{\"added\": {}}]',11,2),(321,'2020-02-20 19:44:27','12','plan viejo -plan nuevo (mix alumnos)',3,'',7,2),(322,'2020-02-20 19:44:46','44','Estudio e implementación de un sistema de alimentación de baterias Li-Ion de baja y mediana potencia - Romero Mónica',2,'[{\"changed\": {\"fields\": [\"plan\"]}}]',10,2),(323,'2020-02-20 20:53:05','12','Caracterización y análisis de un sistema  de vuelo para un vehículo aéreo no tripulado (UAV) - Geninatti Sergio',2,'[{\"changed\": {\"fields\": [\"titulo\"]}}]',10,2),(324,'2020-02-20 20:57:45','14','Implemetnación de una red LORaWAN - Coronel José',2,'[{\"changed\": {\"fields\": [\"alumnos\"]}}]',10,2),(325,'2020-02-20 20:58:49','51','Pellegrino (PlanViejo) Adrián',2,'[{\"changed\": {\"fields\": [\"apellido\"]}}]',8,2),(326,'2020-02-20 20:59:24','14','Implemetnación de una red LORaWAN - Coronel José',2,'[]',10,2),(327,'2020-02-21 01:01:30','121','calviz marcelo',1,'[{\"added\": {}}]',8,2),(328,'2020-02-21 01:02:26','122','Comelli roman',1,'[{\"added\": {}}]',8,2),(329,'2020-02-21 01:04:51','45','Desarrollo de un simulador digital de máquina sincronica en tiempo real controlado a tarvés de internet - Romero Mónica',1,'[{\"added\": {}}]',10,2),(330,'2020-02-21 01:09:25','123','Mochi Leandro',1,'[{\"added\": {}}]',8,2),(331,'2020-02-21 01:11:07','46','SISTEMA SEMIAUTOMATICO DE ENSAYOS PARA LAVARROPAS - Gentile Aldo',1,'[{\"added\": {}}]',10,2),(332,'2020-02-21 01:17:57','124','Córdoba Pablo',1,'[{\"added\": {}}]',8,2),(333,'2020-02-21 01:18:43','125','Sanchez Mario',1,'[{\"added\": {}}]',8,2),(334,'2020-02-21 01:21:11','47','Sistema de comunicación remota para carteles LED - Gentile Aldo',1,'[{\"added\": {}}]',10,2),(335,'2020-02-21 01:21:55','37','Minnucci Gustavo',2,'[{\"changed\": {\"fields\": [\"apellido\"]}}]',9,2),(336,'2020-02-21 01:22:27','47','Sistema de comunicación remota para carteles LED - Minnucci Gustavo',2,'[{\"changed\": {\"fields\": [\"director\"]}}]',10,2),(337,'2020-02-21 01:23:37','126','Arn Santiago',1,'[{\"added\": {}}]',8,2),(338,'2020-02-21 01:25:30','48','red publica de sonómetros con conecttividad via telefonos inteligentes - Miyara Federico',1,'[{\"added\": {}}]',10,2),(339,'2020-02-21 01:28:53','127','Gerhardt Juan',1,'[{\"added\": {}}]',8,2),(340,'2020-02-21 01:30:22','49','sistema de supervisión remota de generación - Gentile Aldo',1,'[{\"added\": {}}]',10,2),(341,'2020-02-21 01:30:47','44','Monti sergio',1,'[{\"added\": {}}]',9,2),(342,'2020-02-21 01:31:19','49','sistema de supervisión remota de generación - Monti sergio',2,'[{\"changed\": {\"fields\": [\"director\"]}}]',10,2),(343,'2020-02-21 01:33:37','128','juretich cristian',1,'[{\"added\": {}}]',8,2),(344,'2020-02-21 01:35:58','129','Herbas franco',1,'[{\"added\": {}}]',8,2),(345,'2020-02-21 01:38:30','50','portero visor digital con conectividad internet y apilcación android de gestión - Gentile Aldo',1,'[{\"added\": {}}]',10,2),(346,'2020-02-21 01:38:54','45','belmonte javier',1,'[{\"added\": {}}]',9,2),(347,'2020-02-21 01:39:24','50','portero visor digital con conectividad internet y apilcación android de gestión - belmonte javier',2,'[{\"changed\": {\"fields\": [\"director\"]}}]',10,2),(348,'2020-02-21 01:41:02','130','Bufarini Mauro',1,'[{\"added\": {}}]',8,2),(349,'2020-02-21 01:43:41','51','Automatización de micro cervecería - Gentile Aldo',1,'[{\"added\": {}}]',10,2),(350,'2020-02-21 01:44:10','46','Sosa ignacio',1,'[{\"added\": {}}]',9,2),(351,'2020-02-21 01:45:41','51','Automatización de micro cervecería - Sosa ignacio',2,'[{\"changed\": {\"fields\": [\"director\"]}}]',10,2),(352,'2020-02-21 01:46:29','47','Muro gustavo',1,'[{\"added\": {}}]',9,2),(353,'2020-02-21 01:47:04','51','Automatización de micro cervecería - Sosa ignacio',2,'[{\"changed\": {\"fields\": [\"asesor\"]}}]',10,2),(354,'2020-02-21 01:49:52','131','Gambetta Luciano',1,'[{\"added\": {}}]',8,2),(355,'2020-02-21 01:51:50','132','genre bert Jairo',1,'[{\"added\": {}}]',8,2),(356,'2020-02-21 01:53:24','52','automatización linea de subarmado de heladeras - Gentile Aldo',1,'[{\"added\": {}}]',10,2),(357,'2020-02-21 01:58:50','133','canans Gabriel',1,'[{\"added\": {}}]',8,2),(358,'2020-02-21 02:00:38','53','Estudio e implementación de un sistema DAG - Novello Armando',1,'[{\"added\": {}}]',10,2),(359,'2020-02-21 02:02:59','134','Molex Brian',1,'[{\"added\": {}}]',8,2),(360,'2020-02-21 02:03:56','135','Scilabra Martin',1,'[{\"added\": {}}]',8,2),(361,'2020-02-21 03:04:47','54','Centro de monitoreo IoT - Arraigada Fernando',1,'[{\"added\": {}}]',10,2),(362,'2020-02-21 03:15:40','136','rostagno ignacio',1,'[{\"added\": {}}]',8,2),(363,'2020-02-21 03:18:07','55','Conversor de modbus TCP a modbus RTU o ASCII con interface WIFI, RS485 y rs232 a limentado a bateria - Novello Armando',1,'[{\"added\": {}}]',10,2),(364,'2020-02-21 03:25:07','56','DISEÑO DE UN ROBOT MÓVIL (proyecto en francia) - Gentile Aldo',1,'[{\"added\": {}}]',10,2),(365,'2020-02-21 03:25:45','31','diseño e implementación de hardware y software de control de un manipulador robótico de tipo industrial - Nacusse Matías',2,'[{\"changed\": {\"fields\": [\"alumnos\"]}}]',10,2),(366,'2020-02-21 03:39:36','9','Desarrollo e implementacón de un sistema de sensado y posicionamiento en prototipo de robot desmalezador - Kofman Ernesto',2,'[{\"changed\": {\"fields\": [\"plan\"]}}]',10,2),(367,'2020-02-21 03:40:20','52','automatización linea de subarmado de heladeras - Gentile Aldo',2,'[{\"changed\": {\"fields\": [\"plan\"]}}]',10,2),(368,'2020-02-21 03:42:37','5','Sistema de enlace inlámbrio de bajo consumo - Molina Hector',2,'[{\"changed\": {\"fields\": [\"plan\"]}}]',10,2),(369,'2020-02-21 03:44:10','4','Sistema electrónico de control de procesos - Pastelleto Sergio',2,'[{\"changed\": {\"fields\": [\"plan\"]}}]',10,2),(370,'2020-02-24 20:17:46','137','Muzzio fernando',1,'[{\"added\": {}}]',8,2),(371,'2020-02-24 20:18:57','138','Magnano sebastian',1,'[{\"added\": {}}]',8,2),(372,'2020-02-24 20:19:42','139','Marrone alfredo',1,'[{\"added\": {}}]',8,2),(373,'2020-02-24 20:21:59','57','Sistema de monitoreo apicola - Gentile Aldo',1,'[{\"added\": {}}]',10,2),(374,'2020-02-24 20:25:54','140','Chiapponi emiliano',1,'[{\"added\": {}}]',8,2),(375,'2020-02-24 20:26:54','141','Forte bruno',1,'[{\"added\": {}}]',8,2),(376,'2020-02-24 20:29:02','58','desarrollo de un lazo de enganche de fase para aplicaciones en energia renovable - Alba Daniel',1,'[{\"added\": {}}]',10,2),(377,'2020-02-24 20:31:54','59','diseño de un sistema de aduqisición de datos para monitoreo contínuo de motores trifásico de inducción - Muro gustavo',1,'[{\"added\": {}}]',10,2),(378,'2020-02-24 20:33:09','142','Cornet juan ignacio',1,'[{\"added\": {}}]',8,2),(379,'2020-02-24 20:33:37','59','diseño de un sistema de aduqisición de datos para monitoreo contínuo de motores trifásico de inducción - Muro gustavo',2,'[{\"changed\": {\"fields\": [\"alumnos\"]}}]',10,2),(380,'2020-02-25 18:01:33','58','desarrollo de un lazo de enganche de fase para aplicaciones en energia renovable - Alba Daniel',2,'[{\"changed\": {\"fields\": [\"plan\"]}}]',10,2),(381,'2020-02-25 18:02:46','40','desarrollo e implementación de un sistema de almacenamiento de energía basado en supercapacitores con aplicaciónen una smart grid - Alba Daniel',2,'[{\"changed\": {\"fields\": [\"plan\"]}}]',10,2),(382,'2020-02-25 18:24:40','5','Sistema de enlace inlámbrio de bajo consumo - Molina Hector',2,'[{\"changed\": {\"fields\": [\"fecha_final\"]}}]',10,2),(383,'2020-03-02 16:53:11','143','Moex Brian',1,'[{\"added\": {}}]',8,2),(384,'2020-03-02 16:54:25','144','Scilabra Martin',1,'[{\"added\": {}}]',8,2),(385,'2020-03-02 16:55:36','144','Scilabra Martin',3,'',8,2),(386,'2020-03-02 16:55:36','143','Moex Brian',3,'',8,2),(387,'2020-03-02 17:07:43','57','Sistema de monitoreo apicola - Gentile Aldo',2,'[{\"changed\": {\"fields\": [\"alumnos\"]}}]',10,2),(388,'2020-03-03 00:57:29','142','Cornet juan ignacio',2,'[{\"changed\": {\"fields\": [\"orientacion\"]}}]',8,2),(389,'2020-03-03 22:43:51','145','Rearte Manuella',1,'[{\"added\": {}}]',8,2),(390,'2020-03-03 22:48:18','146','Villa Angel',1,'[{\"added\": {}}]',8,2),(391,'2020-03-03 22:53:01','60','IPV6 - Mare Renzo',1,'[{\"added\": {}}]',10,2),(392,'2020-03-10 17:46:03','22','sistema automatizado para la identificación, selección y clasficación de piezas discriminadas según el color - Luppi Patricio',2,'[{\"changed\": {\"fields\": [\"fecha_final\"]}}]',10,2),(393,'2020-03-10 17:46:49','24','Desarrollo e implementación de funciones de navegación autónoma para un prototipo de robto desmalezador - Migoni Gustavo',2,'[{\"changed\": {\"fields\": [\"fecha_final\"]}}]',10,2),(394,'2020-03-10 17:47:09','35','telemedición de tanques de combustble - Hendrik Lionel',2,'[{\"changed\": {\"fields\": [\"fecha_anteproyecto\"]}}]',10,2),(395,'2020-04-22 16:13:11','147','Basso juan pablo',1,'[{\"added\": {}}]',8,2),(396,'2020-04-22 16:15:31','61','Detector de anomalias en puntos de red de agua - Gomez Juan Carlos',1,'[{\"added\": {}}]',10,2),(397,'2020-04-22 16:15:51','13','digital 2020',1,'[{\"added\": {}}]',7,2),(398,'2020-04-22 16:16:05','14','comunicaciones 2020',1,'[{\"added\": {}}]',7,2),(399,'2020-04-22 16:16:13','15','control 2020',1,'[{\"added\": {}}]',7,2),(400,'2020-04-22 16:16:38','6','plan 2014- 2020',1,'[{\"added\": {}}]',11,2),(401,'2020-04-22 16:16:48','6','plan 2014- v2020',2,'[{\"changed\": {\"fields\": [\"nombre\"]}}]',11,2),(402,'2020-04-22 16:17:10','147','Basso juan pablo',2,'[{\"changed\": {\"fields\": [\"orientacion\"]}}]',8,2),(403,'2020-04-22 16:17:29','61','Detector de anomalias en puntos de red de agua - Gomez Juan Carlos',2,'[{\"changed\": {\"fields\": [\"orientacion\", \"plan\"]}}]',10,2),(404,'2020-04-27 15:21:24','62','Herramientas de análisis facial basadas en visión por computadora para aplicaciones en fonoaudiología - Sad Gonzalo',1,'[{\"added\": {}}]',10,2),(405,'2020-05-14 13:13:20','148','Diale Guillermo',1,'[{\"added\": {}}]',8,2),(406,'2020-05-14 13:14:04','149','Bertó Nicolas',1,'[{\"added\": {}}]',8,2),(407,'2020-05-14 13:17:23','63','Generador de pulsos para inyectores diesel - Hendrik Lionel',1,'[{\"added\": {}}]',10,2),(408,'2020-05-15 13:49:46','150','gatti sebastian',1,'[{\"added\": {}}]',8,2),(409,'2020-05-15 13:51:12','64','implementación de un scanner 3D con cámras de profundidad - Gomez Juan Carlos',1,'[{\"added\": {}}]',10,2),(410,'2020-05-15 13:53:51','151','Montagna Matías',1,'[{\"added\": {}}]',8,2),(411,'2020-05-15 13:55:08','152','Devetter rodriguez Juan Martín',1,'[{\"added\": {}}]',8,2),(412,'2020-05-15 13:56:30','65','Control automático de temperatura para horno cerámico - Molina Hector',1,'[{\"added\": {}}]',10,2),(413,'2020-05-18 13:35:44','64','implementación de un scanner 3D con cámaras de profundidad - Gomez Juan Carlos',2,'[{\"changed\": {\"fields\": [\"titulo\"]}}]',10,2),(414,'2020-05-25 15:51:41','153','Biagiola, Claudio',1,'[{\"added\": {}}]',8,2),(415,'2020-05-25 15:52:40','154','Castillo Jeremias',1,'[{\"added\": {}}]',8,2),(416,'2020-05-25 15:53:52','155','Campero Gustavo',1,'[{\"added\": {}}]',8,2),(417,'2020-05-25 15:55:37','66','Sistema de Posicionamiento / Tracking para antena satelital. - Minnucci Gustavo',1,'[{\"added\": {}}]',10,2);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_45f3b1d93ec8c61c_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(8,'proyecto','alumno'),(9,'proyecto','director'),(7,'proyecto','orientacion'),(11,'proyecto','plan'),(10,'proyecto','proyecto'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2018-03-24 22:39:20'),(2,'auth','0001_initial','2018-03-24 22:39:22'),(3,'admin','0001_initial','2018-03-24 22:39:23'),(4,'contenttypes','0002_remove_content_type_name','2018-03-24 22:39:23'),(5,'auth','0002_alter_permission_name_max_length','2018-03-24 22:39:23'),(6,'auth','0003_alter_user_email_max_length','2018-03-24 22:39:24'),(7,'auth','0004_alter_user_username_opts','2018-03-24 22:39:24'),(8,'auth','0005_alter_user_last_login_null','2018-03-24 22:39:24'),(9,'auth','0006_require_contenttypes_0002','2018-03-24 22:39:24'),(10,'proyecto','0001_initial','2018-03-24 22:39:27'),(11,'sessions','0001_initial','2018-03-24 22:39:27'),(12,'admin','0002_logentry_remove_auto_add','2019-01-13 00:58:01'),(13,'auth','0007_alter_validators_add_error_messages','2019-01-13 00:58:01'),(14,'auth','0008_alter_user_username_max_length','2019-01-13 00:58:01'),(15,'proyecto','0002_auto_20190402_1235','2019-04-02 15:36:55'),(16,'proyecto','0003_auto_20190402_1237','2019-04-02 15:37:44'),(17,'proyecto','0004_auto_20190402_1243','2019-04-02 15:54:57');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_de54fa62` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('0shd1e690engwz7i8zyiuvtuqg6wr60o','NmIyMzEwNWI5YjMxZjliYzcxMjg3OTMzMTM2NWYxMTBhMWZkMWU1ODp7Il9hdXRoX3VzZXJfaGFzaCI6ImViMzVhYWYyNmFkOGMzYTcyNWU4ZDk3Mjc3ZTY2NWI5NGU2NDE3MDgiLCJfYXV0aF91c2VyX2lkIjoiMiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2019-12-30 22:42:06'),('1vyer3wcl1squbom2yh4k84bba7yslhb','NmFkNTVjNjRhY2UwZWUwNzhiZWEwODUzN2Y5NDY4MzYwYmY5OWY2Mzp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWIzNWFhZjI2YWQ4YzNhNzI1ZThkOTcyNzdlNjY1Yjk0ZTY0MTcwOCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2020-02-25 20:34:31'),('24vbns1tggbu5iqwzjgq3h2pepmhqu40','MjZmZTA3ODA4NDgyOTk4YmY1OTM2MDcwZTg5ZjE3NmU5MGQwMGNjZDp7Il9hdXRoX3VzZXJfaGFzaCI6ImZiOWZiYzMzNzY0MTkyODBiOTI4ODhjZDU4NmNmZGVkZTU1ZGU3MDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2018-09-11 23:08:57'),('2njj4j8b3mmwvjvc22lh19psjqcorwby','YWU2MjVmODc0ZGNjYzJmMTA1ZGI5YWJkZmZiMmVhMDllNWVlYjU2ZTp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlYjM1YWFmMjZhZDhjM2E3MjVlOGQ5NzI3N2U2NjViOTRlNjQxNzA4In0=','2019-03-27 14:21:32'),('3obgsrq3xh980w2qo9znbor55fwifn6x','NmIyMzEwNWI5YjMxZjliYzcxMjg3OTMzMTM2NWYxMTBhMWZkMWU1ODp7Il9hdXRoX3VzZXJfaGFzaCI6ImViMzVhYWYyNmFkOGMzYTcyNWU4ZDk3Mjc3ZTY2NWI5NGU2NDE3MDgiLCJfYXV0aF91c2VyX2lkIjoiMiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2020-04-01 02:37:29'),('3shvcc247f8k7822emjivy0l37k1k7ba','ZjBkYTYzMzhlNTNjYTljM2I2YjI4NzU0MWVmZDQ5NjlhYmQyZjBjMjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWIzNWFhZjI2YWQ4YzNhNzI1ZThkOTcyNzdlNjY1Yjk0ZTY0MTcwOCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2019-12-09 23:42:23'),('49smscaekqc9neafx9uwopupocqijo4b','ZjBkYTYzMzhlNTNjYTljM2I2YjI4NzU0MWVmZDQ5NjlhYmQyZjBjMjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWIzNWFhZjI2YWQ4YzNhNzI1ZThkOTcyNzdlNjY1Yjk0ZTY0MTcwOCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2019-07-09 23:08:41'),('55mboih1u8rxds8uolab18h094u0v4s0','YjI3YjA3Y2ExMGFhZWIzNmViMzg1N2I4ZjFjYWI0YTJmM2FmMGU0NDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiJlYjM1YWFmMjZhZDhjM2E3MjVlOGQ5NzI3N2U2NjViOTRlNjQxNzA4In0=','2019-08-16 20:58:05'),('59mxf2p7hiroku34zryenhz361726jvg','YjI3YjA3Y2ExMGFhZWIzNmViMzg1N2I4ZjFjYWI0YTJmM2FmMGU0NDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiJlYjM1YWFmMjZhZDhjM2E3MjVlOGQ5NzI3N2U2NjViOTRlNjQxNzA4In0=','2020-03-26 18:11:43'),('5ih501bb46wxtkncl4n1hjo3mb10hqmx','NmIyMzEwNWI5YjMxZjliYzcxMjg3OTMzMTM2NWYxMTBhMWZkMWU1ODp7Il9hdXRoX3VzZXJfaGFzaCI6ImViMzVhYWYyNmFkOGMzYTcyNWU4ZDk3Mjc3ZTY2NWI5NGU2NDE3MDgiLCJfYXV0aF91c2VyX2lkIjoiMiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2019-06-20 21:19:25'),('6l21fip4syaelaetp9qcdximybylxfkb','NmIyMzEwNWI5YjMxZjliYzcxMjg3OTMzMTM2NWYxMTBhMWZkMWU1ODp7Il9hdXRoX3VzZXJfaGFzaCI6ImViMzVhYWYyNmFkOGMzYTcyNWU4ZDk3Mjc3ZTY2NWI5NGU2NDE3MDgiLCJfYXV0aF91c2VyX2lkIjoiMiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2019-06-03 23:49:24'),('7cz6h8t8eogfk60yny3hx3o7vi1t3ns5','YWU2MjVmODc0ZGNjYzJmMTA1ZGI5YWJkZmZiMmVhMDllNWVlYjU2ZTp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlYjM1YWFmMjZhZDhjM2E3MjVlOGQ5NzI3N2U2NjViOTRlNjQxNzA4In0=','2019-11-25 22:03:04'),('7j49mdnj6xvp1gewnadfdcvmcb25xtyn','MjZmZTA3ODA4NDgyOTk4YmY1OTM2MDcwZTg5ZjE3NmU5MGQwMGNjZDp7Il9hdXRoX3VzZXJfaGFzaCI6ImZiOWZiYzMzNzY0MTkyODBiOTI4ODhjZDU4NmNmZGVkZTU1ZGU3MDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2019-01-02 12:36:32'),('7l8dhep4d3951i4n8r6hy56x121i8asy','YjI3YjA3Y2ExMGFhZWIzNmViMzg1N2I4ZjFjYWI0YTJmM2FmMGU0NDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiJlYjM1YWFmMjZhZDhjM2E3MjVlOGQ5NzI3N2U2NjViOTRlNjQxNzA4In0=','2019-10-28 22:52:28'),('8defic67s2j4o6vw065qyvrv400tfqbt','ZTlkYTQ3Y2E0OTBhOGI3OTNlMWM3YWJlNDczOGNhMjdhYjQ5YmM3Njp7Il9hdXRoX3VzZXJfaGFzaCI6Ijg2YTM5OWQxZTU4NjcyZmE1ZjVkYTE5OTlmYzY1Mzc4OTIxMmY5MjgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2019-01-18 16:42:44'),('8jozgozirg8f16eg8hxc4evz8hhwevc9','YjI3YjA3Y2ExMGFhZWIzNmViMzg1N2I4ZjFjYWI0YTJmM2FmMGU0NDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiJlYjM1YWFmMjZhZDhjM2E3MjVlOGQ5NzI3N2U2NjViOTRlNjQxNzA4In0=','2020-04-14 19:45:12'),('9kvhlwy3zq8wjrnblebl149h81y9nq3t','NTY3MDcxZGZkZmM5YjI4ZTNlMDc3NTJkNDMwN2FlZTZmY2I4YTQ4Yjp7Il9hdXRoX3VzZXJfaGFzaCI6IjI2ZWFjOTgxZTlkZDUyZGZjNWZjMWJjYjY5MDVhZTQwMGYyMzNlYTAiLCJfYXV0aF91c2VyX2lkIjoiMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2019-07-01 16:31:19'),('9tfy4eygf0puktw7or7wktnfkbnpiqz9','MjZmZTA3ODA4NDgyOTk4YmY1OTM2MDcwZTg5ZjE3NmU5MGQwMGNjZDp7Il9hdXRoX3VzZXJfaGFzaCI6ImZiOWZiYzMzNzY0MTkyODBiOTI4ODhjZDU4NmNmZGVkZTU1ZGU3MDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2018-09-09 15:02:44'),('a4na4i2qvq5d2ldfvtlvn4mvf31cxqoh','NmFkNTVjNjRhY2UwZWUwNzhiZWEwODUzN2Y5NDY4MzYwYmY5OWY2Mzp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWIzNWFhZjI2YWQ4YzNhNzI1ZThkOTcyNzdlNjY1Yjk0ZTY0MTcwOCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2019-12-06 18:57:55'),('atml21km8wgsxnl2qa19wvldol9mph3n','MjZmZTA3ODA4NDgyOTk4YmY1OTM2MDcwZTg5ZjE3NmU5MGQwMGNjZDp7Il9hdXRoX3VzZXJfaGFzaCI6ImZiOWZiYzMzNzY0MTkyODBiOTI4ODhjZDU4NmNmZGVkZTU1ZGU3MDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2019-01-16 15:24:59'),('csnrcbx514by8nr8tisjtgbcr1nj9m7r','YjI3YjA3Y2ExMGFhZWIzNmViMzg1N2I4ZjFjYWI0YTJmM2FmMGU0NDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiJlYjM1YWFmMjZhZDhjM2E3MjVlOGQ5NzI3N2U2NjViOTRlNjQxNzA4In0=','2019-12-24 18:36:43'),('cx2qnyxcc7nhq490fdder48qv5gzt5to','NmFkNTVjNjRhY2UwZWUwNzhiZWEwODUzN2Y5NDY4MzYwYmY5OWY2Mzp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWIzNWFhZjI2YWQ4YzNhNzI1ZThkOTcyNzdlNjY1Yjk0ZTY0MTcwOCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2019-11-27 03:56:17'),('d3vpkz2x7ufunrrcn3hh3u6yjpcaerdp','YWMwOWMwOWJjN2M2OWE2OTIzM2RmYzRkNjVlMmM0Y2QyMzdmYzAyYTp7Il9hdXRoX3VzZXJfaGFzaCI6ImViMzVhYWYyNmFkOGMzYTcyNWU4ZDk3Mjc3ZTY2NWI5NGU2NDE3MDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2020-03-05 20:46:32'),('div8jlqgnc67m3fb9zehd3babml3bwoe','YzgzNTE4M2M4ZGUzYTFkYzgxOTg2YTVlOTdmYTc4N2ZjYTM3MWM0Mjp7Il9hdXRoX3VzZXJfaWQiOiI1IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzYTY0NjcxZjVkOTBjM2NjMThkYzJhN2FjZmEwY2RkZTViODYwOTFkIn0=','2019-01-27 00:58:28'),('dyitnn2prt7633o4hhczbnzm94x7pe5m','MjZmZTA3ODA4NDgyOTk4YmY1OTM2MDcwZTg5ZjE3NmU5MGQwMGNjZDp7Il9hdXRoX3VzZXJfaGFzaCI6ImZiOWZiYzMzNzY0MTkyODBiOTI4ODhjZDU4NmNmZGVkZTU1ZGU3MDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2018-06-22 18:22:28'),('eqqjyox6v1puj80nsqlbgxur96wdbiwh','YjI3YjA3Y2ExMGFhZWIzNmViMzg1N2I4ZjFjYWI0YTJmM2FmMGU0NDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiJlYjM1YWFmMjZhZDhjM2E3MjVlOGQ5NzI3N2U2NjViOTRlNjQxNzA4In0=','2019-04-08 22:04:03'),('fowf0t0hnlwycq1pz8a67dwmgdrpc86x','NmIyMzEwNWI5YjMxZjliYzcxMjg3OTMzMTM2NWYxMTBhMWZkMWU1ODp7Il9hdXRoX3VzZXJfaGFzaCI6ImViMzVhYWYyNmFkOGMzYTcyNWU4ZDk3Mjc3ZTY2NWI5NGU2NDE3MDgiLCJfYXV0aF91c2VyX2lkIjoiMiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2019-04-30 21:12:16'),('gjmqqolrdxi7x4ztt3eg7wtni0ft4p3l','YWMwOWMwOWJjN2M2OWE2OTIzM2RmYzRkNjVlMmM0Y2QyMzdmYzAyYTp7Il9hdXRoX3VzZXJfaGFzaCI6ImViMzVhYWYyNmFkOGMzYTcyNWU4ZDk3Mjc3ZTY2NWI5NGU2NDE3MDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2019-07-08 21:21:13'),('hs1hkv3ofwxsb8b4jqsxbbeuy8qlotgr','ZjBkYTYzMzhlNTNjYTljM2I2YjI4NzU0MWVmZDQ5NjlhYmQyZjBjMjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWIzNWFhZjI2YWQ4YzNhNzI1ZThkOTcyNzdlNjY1Yjk0ZTY0MTcwOCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2019-07-12 21:04:15'),('hxhe8azdzi77fspfvsya7k998dtytcm3','YjI3YjA3Y2ExMGFhZWIzNmViMzg1N2I4ZjFjYWI0YTJmM2FmMGU0NDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiJlYjM1YWFmMjZhZDhjM2E3MjVlOGQ5NzI3N2U2NjViOTRlNjQxNzA4In0=','2019-08-05 21:42:35'),('ikw0hyt2pfht7hfsgfezwb5gj9c4qov5','ZTlkYTQ3Y2E0OTBhOGI3OTNlMWM3YWJlNDczOGNhMjdhYjQ5YmM3Njp7Il9hdXRoX3VzZXJfaGFzaCI6Ijg2YTM5OWQxZTU4NjcyZmE1ZjVkYTE5OTlmYzY1Mzc4OTIxMmY5MjgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2018-04-07 23:06:34'),('j0cbtoixalaidiec9ynt45fl7rc8u7l9','ZjBkYTYzMzhlNTNjYTljM2I2YjI4NzU0MWVmZDQ5NjlhYmQyZjBjMjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWIzNWFhZjI2YWQ4YzNhNzI1ZThkOTcyNzdlNjY1Yjk0ZTY0MTcwOCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2019-10-15 23:04:03'),('j4gh53k02vys9pym7gntsglr3n61sw4x','NmFkNTVjNjRhY2UwZWUwNzhiZWEwODUzN2Y5NDY4MzYwYmY5OWY2Mzp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWIzNWFhZjI2YWQ4YzNhNzI1ZThkOTcyNzdlNjY1Yjk0ZTY0MTcwOCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2020-05-28 13:11:02'),('jj8afi0ym42q4ges5frz319winfu7a86','ZjNkY2JmZjUxZTQxN2I1ZWVmNmIzYzBjYjI4NzE5NWM5NTZiMTNkNDp7Il9hdXRoX3VzZXJfaGFzaCI6IjlhM2YwMTJhOThmMzE4MDc0ZWYxZTI5NTNjOWY4MDhhMzE4ZWNmYzIiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2019-04-16 15:59:08'),('jwsqd5kfgb86vdgwz5kz5y9u062scnvx','NmFkNTVjNjRhY2UwZWUwNzhiZWEwODUzN2Y5NDY4MzYwYmY5OWY2Mzp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWIzNWFhZjI2YWQ4YzNhNzI1ZThkOTcyNzdlNjY1Yjk0ZTY0MTcwOCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2019-09-04 14:50:03'),('khac6uzm09nfdhuv4ff9yqmysjveixc4','NmIyMzEwNWI5YjMxZjliYzcxMjg3OTMzMTM2NWYxMTBhMWZkMWU1ODp7Il9hdXRoX3VzZXJfaGFzaCI6ImViMzVhYWYyNmFkOGMzYTcyNWU4ZDk3Mjc3ZTY2NWI5NGU2NDE3MDgiLCJfYXV0aF91c2VyX2lkIjoiMiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2019-11-11 21:34:20'),('kqrr73ekavbpsdpcpr7mta7431rtu8nr','ZjBkYTYzMzhlNTNjYTljM2I2YjI4NzU0MWVmZDQ5NjlhYmQyZjBjMjp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWIzNWFhZjI2YWQ4YzNhNzI1ZThkOTcyNzdlNjY1Yjk0ZTY0MTcwOCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2019-05-27 17:56:26'),('kx31vp25rmmkg8yyc0krnnhn8l7hkh65','YjI3YjA3Y2ExMGFhZWIzNmViMzg1N2I4ZjFjYWI0YTJmM2FmMGU0NDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiJlYjM1YWFmMjZhZDhjM2E3MjVlOGQ5NzI3N2U2NjViOTRlNjQxNzA4In0=','2020-03-24 22:12:03'),('l47lwqwfwyq787kmx66w6rj1suej9i0a','Njg0N2VjMDJlYzZkZWJlNzhiYTMxYzc0ZGU3ZTc2ZDE3ZTVlNGRiNTp7Il9hdXRoX3VzZXJfaGFzaCI6IjNhNjQ2NzFmNWQ5MGMzY2MxOGRjMmE3YWNmYTBjZGRlNWI4NjA5MWQiLCJfYXV0aF91c2VyX2lkIjoiNSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2019-03-08 13:39:14'),('lil4yqd4psgpextsutpyrid2cc5rlzk7','NmIyMzEwNWI5YjMxZjliYzcxMjg3OTMzMTM2NWYxMTBhMWZkMWU1ODp7Il9hdXRoX3VzZXJfaGFzaCI6ImViMzVhYWYyNmFkOGMzYTcyNWU4ZDk3Mjc3ZTY2NWI5NGU2NDE3MDgiLCJfYXV0aF91c2VyX2lkIjoiMiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2019-09-05 17:00:36'),('m1e5x2r3nqpqavdfppnjfezwfszvhxhb','YzgzNTE4M2M4ZGUzYTFkYzgxOTg2YTVlOTdmYTc4N2ZjYTM3MWM0Mjp7Il9hdXRoX3VzZXJfaWQiOiI1IiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIzYTY0NjcxZjVkOTBjM2NjMThkYzJhN2FjZmEwY2RkZTViODYwOTFkIn0=','2019-01-27 23:47:19'),('ml4jjnda78qrejtr3yrybi92wxsqh15s','NmFkNTVjNjRhY2UwZWUwNzhiZWEwODUzN2Y5NDY4MzYwYmY5OWY2Mzp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWIzNWFhZjI2YWQ4YzNhNzI1ZThkOTcyNzdlNjY1Yjk0ZTY0MTcwOCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2019-09-09 21:41:24'),('n9q4qwflk3bnqgjg1bb8pivfl5x5m1gw','YWMwOWMwOWJjN2M2OWE2OTIzM2RmYzRkNjVlMmM0Y2QyMzdmYzAyYTp7Il9hdXRoX3VzZXJfaGFzaCI6ImViMzVhYWYyNmFkOGMzYTcyNWU4ZDk3Mjc3ZTY2NWI5NGU2NDE3MDgiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2019-09-24 13:50:34'),('o19pybh8zjres7wo13acwxy3dmx02ah1','MjZmZTA3ODA4NDgyOTk4YmY1OTM2MDcwZTg5ZjE3NmU5MGQwMGNjZDp7Il9hdXRoX3VzZXJfaGFzaCI6ImZiOWZiYzMzNzY0MTkyODBiOTI4ODhjZDU4NmNmZGVkZTU1ZGU3MDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2018-08-28 21:56:00'),('ogubupur4bylam6cymoa3fdxt1hxfall','MjZmZTA3ODA4NDgyOTk4YmY1OTM2MDcwZTg5ZjE3NmU5MGQwMGNjZDp7Il9hdXRoX3VzZXJfaGFzaCI6ImZiOWZiYzMzNzY0MTkyODBiOTI4ODhjZDU4NmNmZGVkZTU1ZGU3MDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2018-12-25 22:54:40'),('p34o2jcunngrrbake37jri8riuv4gqdt','NmFkNTVjNjRhY2UwZWUwNzhiZWEwODUzN2Y5NDY4MzYwYmY5OWY2Mzp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWIzNWFhZjI2YWQ4YzNhNzI1ZThkOTcyNzdlNjY1Yjk0ZTY0MTcwOCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2019-03-11 15:37:49'),('pbjpwhu1bs5yz0bwgl1ulh1nw97auhef','MjZmZTA3ODA4NDgyOTk4YmY1OTM2MDcwZTg5ZjE3NmU5MGQwMGNjZDp7Il9hdXRoX3VzZXJfaGFzaCI6ImZiOWZiYzMzNzY0MTkyODBiOTI4ODhjZDU4NmNmZGVkZTU1ZGU3MDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2018-11-21 15:34:56'),('q390pi1csg1zebc64s6soil7c64n7jyw','MjZmZTA3ODA4NDgyOTk4YmY1OTM2MDcwZTg5ZjE3NmU5MGQwMGNjZDp7Il9hdXRoX3VzZXJfaGFzaCI6ImZiOWZiYzMzNzY0MTkyODBiOTI4ODhjZDU4NmNmZGVkZTU1ZGU3MDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2018-08-21 17:47:16'),('qohfzgyl3b3wcfzu79fj5sj5ue9rj2al','NmFkNTVjNjRhY2UwZWUwNzhiZWEwODUzN2Y5NDY4MzYwYmY5OWY2Mzp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9oYXNoIjoiZWIzNWFhZjI2YWQ4YzNhNzI1ZThkOTcyNzdlNjY1Yjk0ZTY0MTcwOCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2019-11-15 16:56:23'),('rx8f5f4uwu8973l3qis9tfij5j1q75xf','YjI3YjA3Y2ExMGFhZWIzNmViMzg1N2I4ZjFjYWI0YTJmM2FmMGU0NDp7Il9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIiwiX2F1dGhfdXNlcl9pZCI6IjIiLCJfYXV0aF91c2VyX2hhc2giOiJlYjM1YWFmMjZhZDhjM2E3MjVlOGQ5NzI3N2U2NjViOTRlNjQxNzA4In0=','2019-04-16 14:59:49'),('sinwhc6gjv7jkekcd8mqq7u8ouds83js','MjZmZTA3ODA4NDgyOTk4YmY1OTM2MDcwZTg5ZjE3NmU5MGQwMGNjZDp7Il9hdXRoX3VzZXJfaGFzaCI6ImZiOWZiYzMzNzY0MTkyODBiOTI4ODhjZDU4NmNmZGVkZTU1ZGU3MDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2018-04-08 21:16:45'),('sswtd724bcpd44084cw7j1e4xe2vjqc3','YWU2MjVmODc0ZGNjYzJmMTA1ZGI5YWJkZmZiMmVhMDllNWVlYjU2ZTp7Il9hdXRoX3VzZXJfaWQiOiIyIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiJlYjM1YWFmMjZhZDhjM2E3MjVlOGQ5NzI3N2U2NjViOTRlNjQxNzA4In0=','2020-05-11 15:19:10'),('thmnbskeiccbvmuxcqlceld5qnlzbu9o','MjZmZTA3ODA4NDgyOTk4YmY1OTM2MDcwZTg5ZjE3NmU5MGQwMGNjZDp7Il9hdXRoX3VzZXJfaGFzaCI6ImZiOWZiYzMzNzY0MTkyODBiOTI4ODhjZDU4NmNmZGVkZTU1ZGU3MDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2018-12-17 01:38:33'),('u05vcolpvz1mi13pjcpiqev8e128lpn2','MjZmZTA3ODA4NDgyOTk4YmY1OTM2MDcwZTg5ZjE3NmU5MGQwMGNjZDp7Il9hdXRoX3VzZXJfaGFzaCI6ImZiOWZiYzMzNzY0MTkyODBiOTI4ODhjZDU4NmNmZGVkZTU1ZGU3MDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2018-05-23 15:29:41'),('ujr687invrux3cghd3m6w5cph83o7r6e','ZTY3MzcyM2Y3ZjU4NTEyZjcwYzk0YjdmM2M2ZjVkMjdjZWM5NTc1YTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyNmVhYzk4MWU5ZGQ1MmRmYzVmYzFiY2I2OTA1YWU0MDBmMjMzZWEwIn0=','2019-06-19 18:36:38'),('urauljo5q5xtzyivsa0fftkwtqj8pwp2','MjZmZTA3ODA4NDgyOTk4YmY1OTM2MDcwZTg5ZjE3NmU5MGQwMGNjZDp7Il9hdXRoX3VzZXJfaGFzaCI6ImZiOWZiYzMzNzY0MTkyODBiOTI4ODhjZDU4NmNmZGVkZTU1ZGU3MDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2018-06-12 22:35:22'),('v5i04hnfd48y9aj5p6mt66qbqew0luwf','MjZmZTA3ODA4NDgyOTk4YmY1OTM2MDcwZTg5ZjE3NmU5MGQwMGNjZDp7Il9hdXRoX3VzZXJfaGFzaCI6ImZiOWZiYzMzNzY0MTkyODBiOTI4ODhjZDU4NmNmZGVkZTU1ZGU3MDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2018-10-10 16:18:14'),('w6aqca9g6peine7aain814a764gbp14r','NmIyMzEwNWI5YjMxZjliYzcxMjg3OTMzMTM2NWYxMTBhMWZkMWU1ODp7Il9hdXRoX3VzZXJfaGFzaCI6ImViMzVhYWYyNmFkOGMzYTcyNWU4ZDk3Mjc3ZTY2NWI5NGU2NDE3MDgiLCJfYXV0aF91c2VyX2lkIjoiMiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2019-12-26 20:04:04'),('w9wer9pi2355y1uvzev337j2skdjt6sr','MjZmZTA3ODA4NDgyOTk4YmY1OTM2MDcwZTg5ZjE3NmU5MGQwMGNjZDp7Il9hdXRoX3VzZXJfaGFzaCI6ImZiOWZiYzMzNzY0MTkyODBiOTI4ODhjZDU4NmNmZGVkZTU1ZGU3MDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2018-11-16 23:39:33'),('wkp5lykfqacbqcclz5x2rfm1e2zfs2ka','MjZmZTA3ODA4NDgyOTk4YmY1OTM2MDcwZTg5ZjE3NmU5MGQwMGNjZDp7Il9hdXRoX3VzZXJfaGFzaCI6ImZiOWZiYzMzNzY0MTkyODBiOTI4ODhjZDU4NmNmZGVkZTU1ZGU3MDYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIyIn0=','2018-10-11 22:16:01'),('zg1gc6y8ynjpy7h2fapjnaz0i2i7lweq','NmIyMzEwNWI5YjMxZjliYzcxMjg3OTMzMTM2NWYxMTBhMWZkMWU1ODp7Il9hdXRoX3VzZXJfaGFzaCI6ImViMzVhYWYyNmFkOGMzYTcyNWU4ZDk3Mjc3ZTY2NWI5NGU2NDE3MDgiLCJfYXV0aF91c2VyX2lkIjoiMiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6ImRqYW5nby5jb250cmliLmF1dGguYmFja2VuZHMuTW9kZWxCYWNrZW5kIn0=','2019-10-09 15:34:05');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_alumno`
--

DROP TABLE IF EXISTS `proyecto_alumno`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_alumno` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `apellido` varchar(255) NOT NULL,
  `legajo` varchar(25) DEFAULT NULL,
  `email` varchar(254) DEFAULT NULL,
  `orientacion_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `proyecto_alumno_cdda5d3e` (`orientacion_id`),
  CONSTRAINT `proye_orientacion_id_5577d3e2a63ccc81_fk_proyecto_orientacion_id` FOREIGN KEY (`orientacion_id`) REFERENCES `proyecto_orientacion` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=156 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_alumno`
--

LOCK TABLES `proyecto_alumno` WRITE;
/*!40000 ALTER TABLE `proyecto_alumno` DISABLE KEYS */;
INSERT INTO `proyecto_alumno` VALUES (1,'Nehuen','Almiron','','almironneuhen@gmail.com',1),(2,'Maia','Andali','','andalimaia@gmail.com',2),(3,'Agustin','Baffo','','agusbaffo@gmail.com',2),(4,'Alex','Barria Cardenas','','alexbarria_14@hotmail.com',4),(5,'Clara','Bureu','','clarabureumakianich@gmail.com',3),(6,'Ignacio','Carnevale','','icarnevale@outlook.com.ar',NULL),(7,'José','Casá','','pepe.casa17@gmail.com',4),(8,'Juan Ignacio','Cavalieri',NULL,'juanignaciocavalieri@gmail.com',4),(9,'Augusto','Chavarini','','chavarinoaugusto@gmail.com',4),(10,'Ian','Chaya','','ianchaya.pr@gmail.com',6),(11,'Augusto','Depetris','','augustodepetris10@gmail.com',6),(12,'Paula','Díaz','','pau.diaz@hotmail.com.ar',4),(13,'Mauro','Dominguez','','mau_igna_06@hotmail.com',1),(14,'Mariano','Echavarria','','marianoemhe@gmail.com',2),(15,'Francisco','Entesano','','entesano.francisco@gmail.com',6),(16,'nicolas','Farina','','nicolasfarina@outlook.com',2),(17,'Fernando','Folmer (NO CLASE)','f-3288/3',NULL,NULL),(18,'Gonzalo','Giacomino','','gonzalo.giacomino@hotmail.com',3),(19,'Juan','Imsand','','juan.imsand@hotmail.com',7),(20,'Guillermo','Isaia (NO CLASE)',NULL,'guillermo.isaia@hotmail.com',NULL),(21,'Emanuel','Magna','','emanuelmagna@gmail.com',4),(22,'Sebastian','Martinez','','vito_seba_17@hotmail.com',3),(23,'Augusto','Masetti','','augmas15@gmail.com',3),(24,'Lucio','Monteros Gavriloff (NO CLASE)','m-6122/1','luciomanuelmonteros@hotlmail.com',NULL),(25,'Martin','Moya',NULL,'moyamartin1@gmail.com',1),(26,'Pablo','Nadal','','nadalpablo.32@gmail.com',6),(27,'leonel','Neumann','','neumann.leonel@gmail.com',4),(28,'Nicolás','Paredes','','nicolasparedes_095@hotmail.com',2),(29,'damian','pilatti','','damianep.unr@gmail.com',1),(30,'Facundo','Piombo','','piombo_7@hotmail.com',6),(31,'Maximiliano','Pozzo','','mpozzo@outlook.com',2),(32,'federico','quattrin','','fede.quattrin@gmail.com',2),(33,'Francisco','Real','','panchoreal_22@hotmail.com',3),(34,'Lucas','Sandoz','','sandozlucas@outlook.com',2),(35,'Gastón','Sgoifo','','gastonsgoifo@gmail.com',3),(37,'Martin','Vazquez (NO CLASE)',NULL,'vazquezmartin@outlook.es',11),(38,'Iván','Vicentin','','ivan_gabriel_11@hotmail.com',3),(39,'Facundo','Vignolo',NULL,NULL,NULL),(40,'Ignacio','Racca','R-2590/9','itrwilly@gmail.com',6),(41,'Matías Nicolas','Manavella','M-5891/2','mn.manavella@gmail.com',1),(42,'Agustín','Acerbo','A-3763/1','agustinacerbo@hotmail.com',1),(43,'Martín ','Rozas','R-3791/5','martin.rsdo@gmail.com',1),(44,'Leandro','Soria','S-4971/9','',1),(45,'Ana Paula','Soraiz','S-4965/4','',1),(46,'martín','Mujica','M-6014/3','martinmujica93@gmail.com',NULL),(47,'Giuliano','Carlachiani','C-6069/1','giuliano2505@gmail.com',1),(48,'Luciano Alejo','Escudero','E-1076/6','luciano.escudero@outlook.com',1),(49,'Luciano','Cordi','C-6066/6','lc.cordi@gamil.com',1),(50,'Fabricio','Rolón','R-3793/1','fabriciorolon@gmail.com',1),(51,'Adrián','Pellegrino (PlanViejo)','P-4464/4','pellegrinoadrianjc@gmail.com',1),(52,'Franco','Di Rosa','D-3670/6','fdr.2013@hotmail.com',1),(53,'Luis','Collazuol','C-5892/1','luiscollazuol@gmail.com',1),(55,'María Florencia','Luque','L-2787/1','mflor.luq@gmail.com',1),(56,'emanuel','mugna','M-6195/6','emanuelmugna@gmail.com',4),(57,'Lucas','Grippo','G-4788/1','lucasgrippo@hotmail.com',1),(58,'Ignacio','Moya','M-5717/7','moyaignacios@gmail.com',1),(59,'Julián','Álvarez','A-3990/1','julian_alvarez96@yahoo.com',9),(60,'Jonatan','Arroyo','A-3736/2','arroyojonatan356@gmail.com',9),(61,'Guillermo','Ascolani','A-3948/9','guillermoascolani@gmail.com',9),(62,'Alex','Cerliani (NO CLASE)','C-5662/6','alexcerliani@hotmail.com',9),(63,'apellido','nombre','legajo','Mail',8),(64,'Andali','Maia Melisa','A-3810/5','andalimaia@gmail.com',9),(65,'Baruzzo','Ariel Jordán','B-5525/5','arielbaruzzo@gmail.com',9),(66,'Bolzani','Lucas Alejandro','B-5653/7','lucas_bolzani@hotmail.com',9),(67,'Brauchli','Guillermo','B-5732/1','guillermobrauchli@yahoo.com.ar',9),(68,'Cruz','Jeremías Tomás','C-6137/9','jeretomascruz@hotmail.com',9),(69,'Danura','Sebastián David','D-3803/2','danurasebastian@gmail.com',9),(70,'Lucas Emanuel','Lastorta','L-2782/1','lucaslastorta@hotmail.com',9),(71,'Lucci','Leonardo','L-2769/3','leonardolucci3@gmail.com',9),(72,'Lunari',' Ricardo','L-2847/9','ricardolunari94@gmail.com',3),(73,'Nicolas','Mandrile (NO CLASE)','M-5827/1','mandrilenico@gmail.com',3),(74,'Marinsalti',' Martín','M-6249/9','Marinsaltimartin@gmail.com',3),(75,'Martin','Guillermo Nicolás','M-6047/1','martinguillermo915@gmail.com',9),(76,'Obrador',' Emilio Miguel','O-1603/9','emiliomobrador6@gmail.com',3),(77,'Ivan','Podoroska','P-4367/2','ivanpodoroska@gmail.com',9),(78,'Joaquín','Raimundo','R-4037/1','cojuaraimundo@gmail.com',9),(79,'Franco Nahuel','Seguezzo','S-5135/7','seguezzo.f@hotmail.com',9),(80,'Zoccari',' Marcelo Ezequiel','Z-1100/2','marcelo.zoccari@gmail.com',3),(81,'Tomas','Ayi (NO CLASE)','A-4024/1','tommy.ayi@hotmail.com',10),(82,'Barria Cardenas',' Alex Damian','B-5656/1','alexbarria_14@hotmail.com',4),(83,'Nicolas Roberto','Bazzano','B-5741/1','nico-bazzo@hotmail.com',10),(84,'Lisandro Ariel','Cesaratto','C-6299/5','lisandrocesaratto@hotmail.com',10),(86,'Emanuel','Cima','C-6296/1','emanuel_96_19@hotmail.com',10),(87,'Felipe','Cinto','C-6436/1','cintofelipe.1@gmail.com',10),(88,'Paula Marcela','Diaz','D-3765/6','pau.diaz@hotmail.com.ar',4),(89,'Julian','Gómez','G-5161/6','juliangp@live.com',10),(90,'Kevin Claudio','Kegalj','K-0551/7','keviinn_k@hotmail.com',10),(91,'Lucas Mariano','Parisi','P-4564/1','lucasmparisi@outlook.com',10),(92,'Luciano Nahuel','Perugini Roldan','P-4566/7','peruginiluciano@yahoo.com.ar',10),(93,'Jeremias','Peñas','P-4565/9','jere.lalepra@gmail.com',4),(94,'Facundo Tomas','Reyes','R-4028/2','facundotomasreyes@hotmail.com',10),(95,'Pablo Joel','Rodriguez (NO CLASE)','R-3782/6','pablo_rodriguez_91@hotmail.com',10),(96,'Diego','Sarina','S-5062/8','diego_sarina@hotmail.com',10),(97,'Ignacio','Carnevale','C-3824/5','nchaval@hotmail.com',4),(99,'Echavarria',' Mariano','E-1049/1','marianoemhe@gmail.com',4),(100,'Luciano Antonio','Buono','B-5649/9','luciano.buono@outlook.com',11),(101,'German Agustin','Centurion','C-6297/9','german10.-@hotmail.com',2),(102,'Echavarria',' Mariano Hernan ','E-1039/1 ','marianoemhe@gmail.com',2),(103,'José Luis','Medina Pedreira (NO CLASE)','M-6254/5','pedreiraluis2@hotmail.com',11),(104,'Diego Gabriel','Mussolini','M-4253/6','ego159@hotmail.com',NULL),(105,'Agustín','Pizzarello','P-4468/7','titi.pizzarello@outlook.com',2),(106,'Martín','Raveglia','R-3908/1','ravegliamartin@gmail.com',2),(107,'Franco Agustín','Scoccimarra','S-4977/8','franco_spe@hotmail.com',11),(108,'Esteban','Simich (NO CLASE)','S-4940/9','Simichesteban@gmail.com',11),(109,'Esteban','Toribio','T-2591/7','toribio.est@gmail.com',2),(110,'Martin Sebastian','Vasquez','V-2698/1','msv_911@hotmail.com',2),(111,'Santiago','Unno','U-0504/5','santi_pitu1@hotmail.com',2),(112,'colman','Ezequiel (NO CLASE)','C-5968/4',NULL,NULL),(113,'Francisco','Sola','S-5067/9',NULL,3),(114,'Mauro','Medina',NULL,'mauro93medina@gmail.com',10),(115,'juan Pablo','Zoppi','Z0580/1',NULL,1),(116,'Joel','Chaya','C-6079/8','joelchaya@gmail.com',9),(117,'Juan Francisco','Abt','A-3947/1',NULL,3),(118,'Diego','Derman','D-3809/1','diegoderman@gmail.com',10),(119,'Lucio','Santos','S-4966/2','lucio.santos2206@gmail.com',1),(120,'Federico','Cecarelli','C-6241/3','fedecdc88@gmail.com',3),(121,'marcelo','calviz','C-6048/8',NULL,1),(122,'roman','Comelli','C-6062/3',NULL,1),(123,'Leandro','Mochi','M-3321/9','leandromochi@hotmail.com',1),(124,'Pablo','Córdoba','C-3668/4','pablo_cesar_cordoba@yahoo.com.ar',1),(125,'Mario','Sanchez','S-2789/8','mariobsanchez@hotmail.com',1),(126,'Santiago','Arn','A-3545/9','santiago.arn@gmail.com',1),(127,'Juan','Gerhardt',NULL,'j.gerhardt@blcges.com',1),(128,'cristian','juretich','j-0534/7','bulijuretich@gmail.com',1),(129,'franco','Herbas','H-1059/6','fran.dns@hotmail.com',1),(130,'Mauro','Bufarini','B-3061/9','mauro.bufarini@gmail.com',1),(131,'Luciano','Gambetta','g-3420/7','gambe86@hotmail.com',1),(132,'Jairo','genre bert','G-4558/6','jairogenrebert@gmail.com',1),(133,'Gabriel','canans','c-5683/9','gabrielblas@gmail.com',1),(134,'Brian','Molex','M-5952/8','moexbrian@gmail.com',1),(135,'Martin','Scilabra','S-4837/2','scilabramartin@gmail.com',1),(136,'ignacio','rostagno','r-3696/1','ignaciorostagno@hotmail.com',1),(137,'fernando','Muzzio','M3959/4','fernandomuzzio@hotmail.com',NULL),(138,'sebastian','Magnano','M3948/9','sema6m@hotmail.com',NULL),(139,'alfredo','Marrone','M-4060/1','alfredomarrone@hotmail.com',NULL),(140,'emiliano','Chiapponi','c-6031/3','chiapponiemiliano@gmail.com',7),(141,'bruno','Forte','f-3221/3','brunoforte93@gmail.com',NULL),(142,'juan ignacio','Cornet','c6120/4','juanignaciocornet@gmail.com',1),(145,'Manuella','Rearte','R-2599/2','manuela.rearte@outlook.com.ar',1),(146,'Angel','Villa','V-2539/9','angel--villa@hotmail.com',NULL),(147,'juan pablo','Basso','B-5091-1','jbasso314@gmail.com',13),(148,'Guillermo','Diale','D-3812/1','guille_diale@hotmail.com',13),(149,'Nicolas','Bertó','B-5754/1','nicolas.berto@hotmail.com',13),(150,'sebastian','gatti','G-4889/5','seba.g.1391@gmail.com',13),(151,'Matías','Montagna','M-6182/4','matymonta11@gmail.com',13),(152,'Juan Martín','Devetter rodriguez','D-3826/1','devetter.jm@gmail.com',13),(153,'Claudio','Biagiola,','B-5771/1','biagiolaclaudio@hotmail.com',13),(154,'Jeremias','Castillo','C-6405/1','jeremiascastillo07@gmail.com',13),(155,'Gustavo','Campero','C-6428/9','gus.campero@gmail.com',13);
/*!40000 ALTER TABLE `proyecto_alumno` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_director`
--

DROP TABLE IF EXISTS `proyecto_director`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_director` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `apellido` varchar(255) NOT NULL,
  `externo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_director`
--

LOCK TABLES `proyecto_director` WRITE;
/*!40000 ALTER TABLE `proyecto_director` DISABLE KEYS */;
INSERT INTO `proyecto_director` VALUES (1,'Aldo','Gentile',0),(3,'Armando','Novello',0),(4,'Sergio','Geninatti',0),(6,'Mónica','Romero',0),(7,'Andres','Vazquez',0),(8,'Juan Carlos','Gomez',0),(9,'Federico','Miyara',0),(10,'Renzo','Mare',0),(11,'Natalia','Iglesias',0),(12,'Fernando','Arraigada',0),(13,'Jose Luis','Simon',0),(14,'Sergio','Pastelleto',0),(15,'Hector','Molina',0),(16,'Verónica','Miro',0),(17,'Eduardo','Rubio Scola',0),(18,'Daniel','Alba',0),(19,'Javier','Cavello',0),(20,'Rosa','Corti',0),(21,'Sergio','Junco',0),(22,'Analia','Pizzi',1),(23,'Diego','Feroldi',1),(24,'Gustavo','Migoni',1),(25,'Matías','Nacusse',0),(26,'Ernesto','Kofman',0),(27,'Eduardo','Venturini',1),(28,'José','Coronel',0),(29,'Pablo','Amoedo',1),(30,'test','test',0),(31,'adrian','Luque',0),(32,'Federico','Miyara',0),(33,'Gonzalo','Sad',0),(34,'Joaquin',' Ezpeleta',0),(35,'Patricio','Luppi',0),(36,'Lucas','Terissi',0),(37,'Gustavo','Minnucci',0),(38,'Lionel','Hendrik',0),(39,'Martín Andres','Crespo',0),(40,'Franco','Del Colle',0),(41,'Matías','Nacusse',0),(42,'Torben','stollte',1),(43,'Bichi','Arnejo',0),(44,'sergio','Monti',0),(45,'javier','belmonte',0),(46,'ignacio','Sosa',0),(47,'gustavo','Muro',0);
/*!40000 ALTER TABLE `proyecto_director` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_orientacion`
--

DROP TABLE IF EXISTS `proyecto_orientacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_orientacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_orientacion`
--

LOCK TABLES `proyecto_orientacion` WRITE;
/*!40000 ALTER TABLE `proyecto_orientacion` DISABLE KEYS */;
INSERT INTO `proyecto_orientacion` VALUES (1,'Plan 99'),(2,'Comunicaciones 2018'),(3,'Control 2018'),(4,'Digital 2018'),(6,'Diseño electrónico 2018'),(7,'Plan 96'),(8,'Orientación'),(9,'control 2019'),(10,'digital 2019'),(11,'comunicaciones 2019'),(13,'digital 2020'),(14,'comunicaciones 2020'),(15,'control 2020');
/*!40000 ALTER TABLE `proyecto_orientacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_plan`
--

DROP TABLE IF EXISTS `proyecto_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_plan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_plan`
--

LOCK TABLES `proyecto_plan` WRITE;
/*!40000 ALTER TABLE `proyecto_plan` DISABLE KEYS */;
INSERT INTO `proyecto_plan` VALUES (1,'plan2014-v2018'),(2,'plan viejo'),(3,'plan viejo'),(4,'plan 2014-v2019'),(5,'plan viejo -plan nuevo (Mix de alumnos)'),(6,'plan 2014- v2020');
/*!40000 ALTER TABLE `proyecto_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_proyecto`
--

DROP TABLE IF EXISTS `proyecto_proyecto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_proyecto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) NOT NULL,
  `fecha_inscripcion` date NOT NULL,
  `fecha_anteproyecto` date DEFAULT NULL,
  `fecha_final` date DEFAULT NULL,
  `anteproyecto` varchar(100) DEFAULT NULL,
  `creado` datetime NOT NULL,
  `modificado` datetime NOT NULL,
  `asesor_id` int(11) DEFAULT NULL,
  `director_id` int(11) DEFAULT NULL,
  `orientacion_id` int(11) DEFAULT NULL,
  `co_director_id` int(11) DEFAULT NULL,
  `plan_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `proyecto_pr_director_id_3b4a8560f92c50e6_fk_proyecto_director_id` (`director_id`),
  KEY `proye_orientacion_id_53f3efafc2c8baf6_fk_proyecto_orientacion_id` (`orientacion_id`),
  KEY `proyecto_proy_asesor_id_24ad705018713d6b_fk_proyecto_director_id` (`asesor_id`),
  KEY `proyecto_proyecto_443058b7` (`co_director_id`),
  KEY `proyecto_proyecto_188ba6de` (`plan_id`),
  CONSTRAINT `co_director_id_refs_id_6eda3aed` FOREIGN KEY (`co_director_id`) REFERENCES `proyecto_director` (`id`),
  CONSTRAINT `plan_id_refs_id_2945dff0` FOREIGN KEY (`plan_id`) REFERENCES `proyecto_plan` (`id`),
  CONSTRAINT `proyecto_proy_asesor_id_24ad705018713d6b_fk_proyecto_director_id` FOREIGN KEY (`asesor_id`) REFERENCES `proyecto_director` (`id`),
  CONSTRAINT `proyecto_proyecto_orientacion_id_a83ccdba_fk_proyecto_` FOREIGN KEY (`orientacion_id`) REFERENCES `proyecto_orientacion` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_proyecto`
--

LOCK TABLES `proyecto_proyecto` WRITE;
/*!40000 ALTER TABLE `proyecto_proyecto` DISABLE KEYS */;
INSERT INTO `proyecto_proyecto` VALUES (2,'Comunicación VX2: estudio e implementación del protocolo IEEE802.11p utilizando tecnologia de Radio Definida por Software  (SDR)','2018-03-12','2018-08-21','2018-12-18','','2018-04-03 23:57:14','2018-12-19 21:30:21',NULL,11,2,NULL,1),(3,'Desarrollo de Instrumentos Digitales de posición aeronáutica','2018-03-01','2018-08-28','2019-12-17','','2018-04-03 23:59:39','2019-12-17 21:35:46',NULL,1,4,NULL,1),(4,'Sistema electrónico de control de procesos','2018-03-01',NULL,NULL,'','2018-05-12 18:14:09','2020-02-21 03:44:10',NULL,14,1,NULL,3),(5,'Sistema de enlace inlámbrio de bajo consumo','2018-04-02',NULL,'2018-12-03','','2018-05-12 18:17:20','2020-02-25 18:24:40',22,15,1,NULL,2),(6,'Sistema de Gestión Energia para Microredes Inteligentes','2018-05-15',NULL,'2019-08-12','','2018-05-16 00:32:39','2019-10-07 03:01:48',23,6,1,NULL,2),(7,'control de trayectoria para navegación autónoma de robot móvil con plataform omniwheel','2018-05-14','2018-10-16','2019-11-26','','2018-05-21 22:32:52','2019-11-26 16:03:25',24,25,3,NULL,1),(8,'Medición de respuesta al impulso y su aplicación a un plugin de reverberación','2018-02-04','2018-10-29',NULL,'','2018-05-21 22:43:55','2018-10-29 23:25:57',4,9,4,NULL,1),(9,'Desarrollo e implementacón de un sistema de sensado y posicionamiento en prototipo de robot desmalezador','2018-02-05','2018-10-16',NULL,'','2018-05-21 23:03:25','2020-02-21 03:39:36',NULL,26,1,NULL,2),(10,'Dispositivo para la calibración de herramientas de control para interruptores diferenciales','2018-04-03',NULL,NULL,'','2018-05-21 23:07:20','2019-04-03 18:10:32',NULL,4,1,NULL,2),(11,'Generador de pulsos para estimulación del corazón','2018-04-20',NULL,NULL,'','2018-05-29 22:38:41','2018-06-06 19:00:23',3,27,4,NULL,1),(12,'Caracterización y análisis de un sistema  de vuelo para un vehículo aéreo no tripulado (UAV)','2018-05-22','2018-10-02','2019-10-28','','2018-05-29 22:52:59','2020-02-20 20:53:05',NULL,4,4,NULL,1),(13,'Emulador digital de amplificadores y efectos para guitarra','2018-05-22','2019-05-06',NULL,'','2018-05-29 22:55:34','2019-07-23 23:25:53',4,9,6,NULL,1),(14,'Implemetnación de una red LORaWAN','2018-05-22','2018-11-05','2019-08-20','','2018-05-29 23:00:11','2020-02-20 20:59:24',NULL,28,2,NULL,1),(15,'Sistema basado en un tubo de impedancia para cacterización acústica de un material','2018-03-01',NULL,NULL,'','2018-06-05 00:29:40','2019-04-03 18:10:08',29,9,1,NULL,2),(16,'Implementación de un sistema de comunicación utilizando VLC','2018-03-01',NULL,NULL,'','2018-07-31 22:16:34','2019-04-03 18:09:51',31,10,1,NULL,2),(17,'Desarrollo e implementación de efecto de guitarra en tiempo real','2018-06-26','2019-03-25','2019-09-17','','2018-07-31 22:28:47','2019-09-18 14:30:44',32,33,4,NULL,1),(18,'demoludador/decodificador HRD para recepción de imágenes satelitales','2018-05-07',NULL,'2019-12-03','','2018-07-31 22:54:18','2020-02-20 18:06:00',NULL,12,1,NULL,2),(19,'Implementación de una capa de comunicación CAN para una micro-red electrica intelligente','2018-03-08','2018-10-02','2019-06-25','','2018-08-14 22:10:24','2019-07-22 21:43:35',NULL,34,2,28,1),(21,'Diseño e implementación de firmware para un rectificador trifáscio controlado PWM con fines didácticos','2018-05-02','2018-10-16',NULL,'','2018-10-22 23:39:45','2018-10-22 23:39:45',29,6,6,NULL,1),(22,'sistema automatizado para la identificación, selección y clasficación de piezas discriminadas según el color','2018-08-06','2018-12-17','2020-03-09','','2018-11-27 22:50:56','2020-03-10 17:46:03',NULL,35,3,NULL,1),(23,'Prototipo de robot delta para la manupulación automática de objetos mediante visón por computadora','2018-03-26','2018-12-17','2019-11-25','','2018-12-19 21:43:46','2019-11-25 23:43:00',NULL,36,4,NULL,1),(24,'Desarrollo e implementación de funciones de navegación autónoma para un prototipo de robto desmalezador','2018-06-04','2018-10-16','2020-03-09','','2018-12-19 21:49:42','2020-03-10 17:46:49',NULL,24,3,NULL,1),(25,'Diseño de un sistema de locomoción para un robot cuadrúpedo','2019-03-04',NULL,NULL,'','2019-03-22 22:56:04','2019-03-22 22:56:04',NULL,25,9,NULL,4),(29,'Automatización del control de las etapas de fermentación, maduración y clarificado del proceso de elaboración de cerveza artesanal','2019-04-15','2020-02-18',NULL,'','2019-04-23 21:33:55','2020-02-18 21:47:26',NULL,14,9,NULL,4),(30,'sistema de control para cultivo hidropónico','2019-04-23',NULL,NULL,'','2019-04-23 22:52:37','2019-05-13 18:08:07',3,1,9,NULL,4),(31,'diseño e implementación de hardware y software de control de un manipulador robótico de tipo industrial','2018-08-01','2019-04-22',NULL,'','2019-04-29 21:33:07','2020-02-21 03:25:45',NULL,25,3,NULL,1),(32,'Dinamómetro inercial para motores de combustíon interna','2019-04-01','2019-06-25',NULL,'','2019-05-06 23:07:25','2019-06-25 23:17:07',NULL,37,10,NULL,4),(33,'prototipo a escala de un vehiculo autónomo para logística en almacén industrial','2019-05-07','2019-08-06',NULL,'','2019-05-13 18:05:45','2019-08-09 17:43:40',NULL,33,10,NULL,4),(34,'Diseño y desarrollo de un anemómetro ultrasónico sin partes móviles','2019-05-13','2019-09-17',NULL,'','2019-05-20 23:52:32','2019-09-18 14:31:08',NULL,37,10,NULL,4),(35,'telemedición de tanques de combustble','2019-06-03','2020-03-09',NULL,'','2019-06-11 23:36:25','2020-03-10 17:47:09',NULL,38,10,NULL,4),(36,'Diseño construcción e implementación de una plataforma móvil con dos sistemas de locomoción y sus respectivos sistema de control','2019-06-25','2019-12-02',NULL,'','2019-06-25 23:20:34','2019-12-02 22:31:38',39,25,9,NULL,4),(37,'control y adquisición de datos de temperatura en fermentadores de cerveza Industriales','2019-03-25',NULL,NULL,'','2019-07-22 21:59:41','2019-07-22 22:00:46',NULL,3,9,NULL,4),(38,'desarrollo e implementación del control del sistema de pulverización de herbicida para un prototipo de robot desmalezador','2019-08-03','2019-10-15',NULL,'','2019-09-03 21:56:35','2019-10-16 23:46:29',NULL,26,9,NULL,4),(39,'Sistema de monitoreo de circulación de bicilcetas a través de procesamiento de imágenes','2019-10-15',NULL,NULL,'','2019-10-22 21:56:10','2019-10-22 23:51:19',8,40,10,NULL,4),(40,'desarrollo e implementación de un sistema de almacenamiento de energía basado en supercapacitores con aplicaciónen una smart grid','2019-06-11','2020-02-10',NULL,'','2019-10-22 22:05:36','2020-02-25 18:02:46',NULL,18,3,NULL,1),(41,'sistema automatizado para el reconocimiento de baches mediante cámara estereo','2019-10-22','2019-11-04',NULL,'','2019-10-22 23:50:55','2019-11-04 21:20:03',NULL,33,9,NULL,4),(42,'sistema de seguimiento de trayectorias para vehiculos sobreactivados con tolrencia a fallas','2019-12-10',NULL,NULL,'','2019-12-10 18:40:49','2019-12-10 18:44:29',NULL,25,3,42,1),(43,'Equipo de Biofeedback EMG Portátil','2019-02-18',NULL,NULL,'','2020-02-20 18:24:34','2020-02-20 18:24:34',NULL,1,1,NULL,2),(44,'Estudio e implementación de un sistema de alimentación de baterias Li-Ion de baja y mediana potencia','2020-02-20',NULL,NULL,'','2020-02-20 19:41:34','2020-02-20 19:44:46',43,6,1,NULL,5),(45,'Desarrollo de un simulador digital de máquina sincronica en tiempo real controlado a tarvés de internet','2017-10-02',NULL,NULL,'','2020-02-21 01:04:51','2020-02-21 01:04:51',29,6,1,NULL,2),(46,'SISTEMA SEMIAUTOMATICO DE ENSAYOS PARA LAVARROPAS','2014-12-08',NULL,NULL,'','2020-02-21 01:11:07','2020-02-21 01:11:07',NULL,1,1,NULL,2),(47,'Sistema de comunicación remota para carteles LED','2014-10-01',NULL,NULL,'','2020-02-21 01:21:11','2020-02-21 01:22:27',NULL,37,1,NULL,2),(48,'red publica de sonómetros con conecttividad via telefonos inteligentes','2016-11-10',NULL,NULL,'','2020-02-21 01:25:30','2020-02-21 01:25:30',NULL,9,1,NULL,2),(49,'sistema de supervisión remota de generación','2017-05-04',NULL,NULL,'','2020-02-21 01:30:22','2020-02-21 01:31:19',NULL,44,1,NULL,2),(50,'portero visor digital con conectividad internet y apilcación android de gestión','2017-12-01',NULL,NULL,'','2020-02-21 01:38:30','2020-02-21 01:39:24',NULL,45,1,NULL,2),(51,'Automatización de micro cervecería','2018-07-01',NULL,NULL,'','2020-02-21 01:43:41','2020-02-21 01:47:04',47,46,1,NULL,2),(52,'automatización linea de subarmado de heladeras','2017-10-01',NULL,NULL,'','2020-02-21 01:53:24','2020-02-21 03:40:20',NULL,1,1,NULL,2),(53,'Estudio e implementación de un sistema DAG','2019-10-01',NULL,NULL,'','2020-02-21 02:00:38','2020-02-21 02:00:38',NULL,3,1,NULL,2),(54,'Centro de monitoreo IoT','2018-11-01',NULL,NULL,'','2020-02-21 03:04:47','2020-02-21 03:04:47',NULL,12,1,NULL,2),(55,'Conversor de modbus TCP a modbus RTU o ASCII con interface WIFI, RS485 y rs232 a limentado a bateria','2019-09-02',NULL,NULL,'','2020-02-21 03:18:07','2020-02-21 03:18:07',NULL,3,1,NULL,3),(56,'DISEÑO DE UN ROBOT MÓVIL (proyecto en francia)','2019-09-06',NULL,NULL,'','2020-02-21 03:25:07','2020-02-21 03:25:07',NULL,1,3,NULL,1),(57,'Sistema de monitoreo apicola','2019-07-22',NULL,NULL,'','2020-02-24 20:21:59','2020-03-02 17:07:43',NULL,1,7,NULL,2),(58,'desarrollo de un lazo de enganche de fase para aplicaciones en energia renovable','2019-05-06',NULL,NULL,'','2020-02-24 20:29:02','2020-02-25 18:01:33',NULL,18,7,29,3),(59,'diseño de un sistema de aduqisición de datos para monitoreo contínuo de motores trifásico de inducción','2019-04-22',NULL,NULL,'','2020-02-24 20:31:54','2020-02-24 20:33:37',NULL,47,1,NULL,2),(60,'IPV6','2017-03-06',NULL,NULL,'','2020-03-03 22:53:01','2020-03-03 22:53:01',NULL,10,1,NULL,2),(61,'Detector de anomalias en puntos de red de agua','2020-04-13',NULL,NULL,'','2020-04-22 16:15:31','2020-04-22 16:17:29',4,8,13,NULL,6),(62,'Herramientas de análisis facial basadas en visión por computadora para aplicaciones en fonoaudiología','2020-04-06',NULL,NULL,'','2020-04-27 15:21:24','2020-04-27 15:21:24',NULL,33,15,NULL,6),(63,'Generador de pulsos para inyectores diesel','2020-05-11',NULL,NULL,'','2020-05-14 13:17:23','2020-05-14 13:17:23',NULL,38,13,NULL,6),(64,'implementación de un scanner 3D con cámaras de profundidad','2020-05-11',NULL,NULL,'','2020-05-15 13:51:12','2020-05-18 13:35:44',4,8,13,NULL,6),(65,'Control automático de temperatura para horno cerámico','2020-05-11',NULL,NULL,'','2020-05-15 13:56:30','2020-05-15 13:56:30',NULL,15,15,NULL,6),(66,'Sistema de Posicionamiento / Tracking para antena satelital.','2020-04-20',NULL,NULL,'','2020-05-25 15:55:37','2020-05-25 15:55:37',NULL,37,13,NULL,6);
/*!40000 ALTER TABLE `proyecto_proyecto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyecto_proyecto_alumnos`
--

DROP TABLE IF EXISTS `proyecto_proyecto_alumnos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyecto_proyecto_alumnos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_id` int(11) NOT NULL,
  `alumno_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `proyecto_id` (`proyecto_id`,`alumno_id`),
  KEY `proyecto_proyec_alumno_id_1547f865ea22cda2_fk_proyecto_alumno_id` (`alumno_id`),
  CONSTRAINT `proyecto_pr_proyecto_id_1ba067719de7959b_fk_proyecto_proyecto_id` FOREIGN KEY (`proyecto_id`) REFERENCES `proyecto_proyecto` (`id`),
  CONSTRAINT `proyecto_proyec_alumno_id_1547f865ea22cda2_fk_proyecto_alumno_id` FOREIGN KEY (`alumno_id`) REFERENCES `proyecto_alumno` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyecto_proyecto_alumnos`
--

LOCK TABLES `proyecto_proyecto_alumnos` WRITE;
/*!40000 ALTER TABLE `proyecto_proyecto_alumnos` DISABLE KEYS */;
INSERT INTO `proyecto_proyecto_alumnos` VALUES (69,2,16),(70,2,28),(71,2,31),(45,3,26),(44,3,40),(8,4,41),(9,4,42),(10,5,44),(11,6,45),(59,7,5),(60,7,7),(62,8,4),(61,8,8),(57,9,46),(17,10,47),(32,11,12),(31,11,48),(52,12,33),(54,12,49),(53,12,50),(26,13,10),(27,13,11),(66,14,14),(117,14,51),(33,15,52),(34,15,53),(43,16,55),(35,17,21),(41,18,57),(42,18,58),(65,19,3),(64,19,34),(58,21,15),(72,22,35),(73,22,38),(81,23,9),(82,23,27),(78,24,18),(79,24,19),(80,24,22),(83,25,59),(84,25,94),(89,29,60),(90,29,77),(91,30,68),(92,30,69),(93,30,116),(95,31,30),(96,32,90),(97,33,83),(98,33,84),(99,34,114),(100,35,81),(101,36,79),(102,36,87),(104,37,78),(103,37,89),(105,38,17),(106,38,20),(107,39,91),(108,39,92),(109,40,113),(110,40,117),(111,41,118),(112,42,23),(113,43,115),(115,44,25),(116,44,119),(114,44,120),(118,45,121),(119,45,122),(120,46,123),(121,47,124),(122,47,125),(123,48,126),(124,49,127),(125,50,128),(126,50,129),(127,51,130),(128,52,131),(129,52,132),(130,53,133),(131,54,134),(132,54,135),(133,55,136),(134,56,24),(141,57,137),(135,57,138),(136,57,139),(137,58,140),(138,58,141),(140,59,142),(142,60,145),(143,60,146),(144,61,147),(145,62,59),(146,62,94),(147,63,148),(148,63,149),(149,64,150),(151,65,151),(150,65,152),(152,66,153),(153,66,154),(154,66,155);
/*!40000 ALTER TABLE `proyecto_proyecto_alumnos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyectos_director`
--

DROP TABLE IF EXISTS `proyectos_director`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyectos_director` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `apellido` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `externo` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyectos_director`
--

LOCK TABLES `proyectos_director` WRITE;
/*!40000 ALTER TABLE `proyectos_director` DISABLE KEYS */;
/*!40000 ALTER TABLE `proyectos_director` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyectos_orientacion`
--

DROP TABLE IF EXISTS `proyectos_orientacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyectos_orientacion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyectos_orientacion`
--

LOCK TABLES `proyectos_orientacion` WRITE;
/*!40000 ALTER TABLE `proyectos_orientacion` DISABLE KEYS */;
/*!40000 ALTER TABLE `proyectos_orientacion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyectos_plan`
--

DROP TABLE IF EXISTS `proyectos_plan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyectos_plan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyectos_plan`
--

LOCK TABLES `proyectos_plan` WRITE;
/*!40000 ALTER TABLE `proyectos_plan` DISABLE KEYS */;
/*!40000 ALTER TABLE `proyectos_plan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyectos_proyecto`
--

DROP TABLE IF EXISTS `proyectos_proyecto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyectos_proyecto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) COLLATE utf8_spanish_ci NOT NULL,
  `fecha_inscripcion` date NOT NULL,
  `fecha_anteproyecto` date DEFAULT NULL,
  `fecha_final` date DEFAULT NULL,
  `anteproyecto` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `creado` datetime(6) NOT NULL,
  `modificado` datetime(6) NOT NULL,
  `asesor_id` int(11) DEFAULT NULL,
  `co_director_id` int(11) DEFAULT NULL,
  `director_id` int(11) NOT NULL,
  `orientacion_id` int(11) NOT NULL,
  `plan_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `proyectos_proyecto_asesor_id_cf1d42a2_fk_proyectos_director_id` (`asesor_id`),
  KEY `proyectos_proyecto_co_director_id_95a80c19_fk_proyectos` (`co_director_id`),
  KEY `proyectos_proyecto_director_id_4ed0799b_fk_proyectos_director_id` (`director_id`),
  KEY `proyectos_proyecto_orientacion_id_5bced4ce_fk_proyectos` (`orientacion_id`),
  KEY `proyectos_proyecto_plan_id_10490a50_fk_proyectos_plan_id` (`plan_id`),
  CONSTRAINT `proyectos_proyecto_asesor_id_cf1d42a2_fk_proyectos_director_id` FOREIGN KEY (`asesor_id`) REFERENCES `proyectos_director` (`id`),
  CONSTRAINT `proyectos_proyecto_co_director_id_95a80c19_fk_proyectos` FOREIGN KEY (`co_director_id`) REFERENCES `proyectos_director` (`id`),
  CONSTRAINT `proyectos_proyecto_director_id_4ed0799b_fk_proyectos_director_id` FOREIGN KEY (`director_id`) REFERENCES `proyectos_director` (`id`),
  CONSTRAINT `proyectos_proyecto_orientacion_id_5bced4ce_fk_proyectos` FOREIGN KEY (`orientacion_id`) REFERENCES `proyectos_orientacion` (`id`),
  CONSTRAINT `proyectos_proyecto_plan_id_10490a50_fk_proyectos_plan_id` FOREIGN KEY (`plan_id`) REFERENCES `proyectos_plan` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyectos_proyecto`
--

LOCK TABLES `proyectos_proyecto` WRITE;
/*!40000 ALTER TABLE `proyectos_proyecto` DISABLE KEYS */;
/*!40000 ALTER TABLE `proyectos_proyecto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proyectos_proyecto_alumnos`
--

DROP TABLE IF EXISTS `proyectos_proyecto_alumnos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proyectos_proyecto_alumnos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proyecto_id` int(11) NOT NULL,
  `alumno_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `proyectos_proyecto_alumnos_proyecto_id_alumno_id_0b56f740_uniq` (`proyecto_id`,`alumno_id`),
  KEY `proyectos_proyecto_a_alumno_id_8a16c824_fk_proyectos` (`alumno_id`),
  CONSTRAINT `proyectos_proyecto_a_alumno_id_8a16c824_fk_proyectos` FOREIGN KEY (`alumno_id`) REFERENCES `proyectos_alumno` (`id`),
  CONSTRAINT `proyectos_proyecto_a_proyecto_id_990a5a80_fk_proyectos` FOREIGN KEY (`proyecto_id`) REFERENCES `proyectos_proyecto` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proyectos_proyecto_alumnos`
--

LOCK TABLES `proyectos_proyecto_alumnos` WRITE;
/*!40000 ALTER TABLE `proyectos_proyecto_alumnos` DISABLE KEYS */;
/*!40000 ALTER TABLE `proyectos_proyecto_alumnos` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-29 14:42:04
